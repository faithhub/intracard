<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class BillHistory extends Model
{
    
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'uuid',
        'bill_id',
        'user_id',
        'card_id',
        'status',
        'provider',
        'due_date',
        'account_number',
        'frequency',
        'car_model',
        'car_year',
        'car_vin',
        'phone',
    ];

    /**
     * The attributes that should be encrypted.
     *
     * @var array<int, string>
     */
    protected $casts = [
        'provider' => 'encrypted',
        'due_date' => 'encrypted',
        'account_number' => 'encrypted',
        'frequency' => 'encrypted',
        'car_model' => 'encrypted',
        'car_year' => 'encrypted',
        'car_vin' => 'encrypted',
        'phone' => 'encrypted',
    ];

    /**
     * Boot function for the model.
     */
    protected static function boot()
    {
        parent::boot();

        // Automatically generate a UUID for each bill history entry
        static::creating(function ($model) {
            $model->uuid = (string) Str::uuid();
        });
    }
}

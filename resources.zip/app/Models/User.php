<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{

    use HasApiTokens; // Add this trait
    use SoftDeletes;
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'middle_name',
        'email',
        'phone',
        'status',
        'password',
        'otp_code',
        'otp_expires_at',
        'otp_verified',
        'account_goal',
        'account_type',
        'payment_setup',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'first_name' => 'encrypted', // Encrypt first name
            'last_name' => 'encrypted', // Encrypt last name
            'middle_name' => 'encrypted', // Encrypt middle name
            // 'email' => 'encrypted',      // Encrypt email
            // 'phone' => 'encrypted',      // Encrypt phone
            // 'status' => 'encrypted',     // Encrypt status
            // 'account_goal' => 'encrypted', // Encrypt account goal
            // 'account_type' => 'encrypted', // Encrypt account type
            // 'payment_setup' => 'encrypted', // Encrypt payment setup
            // 'otp_code' => 'encrypted',   // Encrypt OTP code
            'otp_verified' => 'boolean', // Cast OTP verified to boolean
            'email_verified_at' => 'datetime', // Handle email verified datetime
            'password' => 'hashed', // Automatically hash password
        ];
    }

    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uuid)) {
                $model->uuid = Str::uuid();
            }
        });
        //     parent::boot();

        //     static::creating(function ($user) {
        //         if (empty($user->email)) {
        //             \Log::info('Creating User - Email is empty:', ['user' => $user]);
        //             throw new \Exception('Email cannot be empty.');
        //         }

        //         // Decrypt the email if it is encrypted
        //         $email = is_string($user->email) ? Crypt::decryptString($user->email) : $user->email;

        //         \Log::info('Creating User - Decrypted Email:', ['email' => $email]);

        //         $user->email_hash = hash('sha256', trim(strtolower($email)));
        //     });

        //     static::updating(function ($user) {
        //         if ($user->isDirty('email')) {
        //             $email = is_string($user->email) ? $user->email : Crypt::decrypt($user->email);

        //             $user->email_hash = hash('sha256', trim(strtolower($email)));
        //         }
        //     });
    }

    // Decrypt email when accessed
    // public function getEmailAttribute($value)
    // {
    //     return Crypt::decrypt($value);
    // }

    public function tickets()
    {
        return $this->belongsToMany(Ticket::class, 'ticket_participants');
    }
    public function getRouteKeyName()
    {
        return 'uuid';
    }

    /**
     * Hash the password before saving.
     */
    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    // Encrypt sensitive attributes
    // public function setAttribute($key, $value)
    // {
    //     $fieldsToEncrypt = ['first_name', 'last_name', 'middle_name', 'phone', 'account_details', 'address_details', 'landlord_or_finance_details'];

    //     if (in_array($key, $fieldsToEncrypt) && $value !== null) {
    //         $value = Crypt::encrypt($value);
    //     }

    //     parent::setAttribute($key, $value);
    // }

    // Decrypt sensitive attributes
    // public function getAttribute($key)
    // {
    //     $fieldsToDecrypt = ['first_name', 'last_name', 'middle_name', 'phone', 'account_details', 'address_details', 'landlord_or_finance_details'];

    //     $value = parent::getAttribute($key);

    //     if (in_array($key, $fieldsToDecrypt) && $value !== null) {
    //         try {
    //             return Crypt::decrypt($value);
    //         } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
    //             return null; // Handle invalid decryption gracefully
    //         }
    //     }

    //     return $value;
    // }
    public function transactions()
    {
        return $this->hasMany(CardTransaction::class);
    }

}

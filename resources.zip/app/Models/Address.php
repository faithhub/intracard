<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Address extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'uuid',
        'user_id',
        'name',
        'amount',
        'province',
        'city',
        'street_name',
        'postal_code',
        'house_number',
        'unit_number',
        'tenancyAgreement',
        'duration_day',
        'reoccurring_monthly_day',
        'duration_from',
        'duration_to',
    ];

    /**
     * Automatically encrypt sensitive fields.
     */
    protected $casts = [
        'name' => 'encrypted',
        'province' => 'encrypted',
        'tenancyAgreement' => 'encrypted',
        'city' => 'encrypted',
        'street_name' => 'encrypted',
        'postal_code' => 'encrypted',
        'house_number' => 'encrypted',
        'unit_number' => 'encrypted',
    ];

    /**
     * Boot function to handle UUID generation.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->uuid = (string) Str::uuid();
        });
    }
       /**
     * Accessor to format the amount with 2 decimal places.
     *
     * @return string
     */
    // public function getAmountAttribute($value)
    // {
    //     return number_format((float) decrypt($value), 2, '.', '');
    // }

    /**
     * Mutator to ensure the amount is encrypted when set.
     *
     * @param  mixed  $value
     * @return void
     */
    // public function setAmountAttribute($value)
    // {
    //     $this->attributes['amount'] = encrypt(number_format((float) $value, 2, '.', ''));
    // }

        /**
     * Define a relationship to the user.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}

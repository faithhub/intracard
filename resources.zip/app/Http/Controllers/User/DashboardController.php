<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Mail\SendVerificationCode;
use App\Models\Member;
use App\Models\Team;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class DashboardController extends Controller
{
    public function index()
    {
        try {
            //code...
            $data['dashboard_title'] = "My Dashboard";
            return view('user.index', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function mortgage()
    {
        try {
            //code...
            $data['dashboard_title'] = "Mortgage Details";
            return view('user.mortgage', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function rental()
    {
        try {
            //code...
            $data['dashboard_title'] = "Rental Details";
            return view('user.rent', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function profile()
    {
        try {
            //code...
            $data['dashboard_title'] = "Rental Details";
            $data['team'] = $team = Team::where('admin_id',Auth::user()->id)->first();
            $data['members'] = Member::where('team_id',$team->id)->get();
            return view('user.profile', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function password()
    {
        try {
            //code...
            $data['dashboard_title'] = "Rental Details";
            return view('user.password', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function advisory()
    {
        try {
            //code...
            $data['dashboard_title'] = "Credit Advisory";
            return view('user.advisory', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
    public function getCalendarEvents()
    {
        // Simulated address details from the database or another source
        $addressDetails = json_decode(Auth::user()->address_details, true);
        $account_type = Auth::user()->account_type; // Get account type dynamically

        // Extract duration details
        $startDate = Carbon::parse($addressDetails['duration']['from']);
        $endDate = Carbon::parse($addressDetails['duration']['to']);

        // Generate events based on rent or mortgage duration
        $events = [];

        // Add last payment as an event
        $events[] = [
            'title' => 'Last Payment',
            'start' => '2024-08-15',
            'description' => 'Last payment of $718.00, status: Paid',
            'amount' => 718.00, // Optional: Include payment amount
            'status' => 'Paid', // Optional: Include status
            'color' => '#133f1a', // Yellow
        ];

        // Add upcoming payment as an event
        $events[] = [
            'title' => 'Upcoming Payment Due',
            'start' => '2024-12-15',
            'description' => 'Upcoming payment of $700.00, status: Pending',
            'amount' => 700.00, // Optional: Include payment amount
            'status' => 'Pending', // Optional: Include status
            'color' => '#40C057', // Yellow
        ];

        while ($startDate <= $endDate) {
            // Determine whether to use "rent" or "mortgage"
            $paymentType = $account_type === 'rent' ? 'Rent' : 'Mortgage';
            $descriptionPrefix = $account_type === 'rent' ? 'Monthly rent payment for ' : 'Monthly mortgage payment for ';

            $events[] = [
                'title' => "{$paymentType} Payment Due", // Rent Payment Due or Mortgage Payment Due
                'start' => $startDate->format('Y-m-d'),
                'end' => $startDate->copy()->addDay()->format('Y-m-d'), // Optional: Add one day for an "end" time
                'description' => $descriptionPrefix . $addressDetails['address'],
                'amount' => $addressDetails['rentAmount'], // Optional: Include rent amount if needed
                'color' => '#FFC53D', // Yellow
            ];

            // Move to the next month
            $startDate->addMonth();
        }

        // Return events as JSON
        return response()->json($events);
    }

    public function checkEmailExists(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $emailExists = User::where('email', $request->email)->exists();

        if ($emailExists) {
            return response()->json(['status' => 'error', 'message' => 'Email already exists.'], 409); // 409 Conflict
        }

        return response()->json(['status' => 'success', 'message' => 'Email is available.'], 200);
    }

    public function sendPhoneVerificationCode(Request $request)
    {
        try {
            // Validate phone number format
            $request->validate([
                'phone' => 'required|string|', // Canadian phone number with +1 code
            ]);

            // Generate a 6-digit verification code
            $code = rand(100000, 999999);
            $phone = $request->input('phone');

            // Store the code in the session using the phone number as the key
            Session::put("verification_code_{$phone}", $code);

            // Send the code via Twilio
            // $twilio = new Client(env('TWILIO_SID'), env('TWILIO_AUTH_TOKEN'));

            // $twilio->messages->create($phone, [
            //     'from' => env('TWILIO_PHONE_NUMBER'),
            //     'body' => "Your CrediPay verification code is: $code",
            // ]);

            return response()->json(['message' => 'Verification code sent successfully.']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Invalid phone number format.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Twilio\Exceptions\RestException $e) {
            // Handle Twilio API errors
            return response()->json([
                'message' => 'Failed to send SMS via Twilio.',
                'error' => $e->getMessage(),
            ], 500);
        } catch (\Throwable $th) {
            // Handle any other errors
            return response()->json([
                'message' => 'An unexpected error occurred while sending the verification code.',
                'error' => $th->getMessage(),
            ], 500);
        }
    }

    public function sendEmailCode(Request $request)
    {
        try {
            // Validate the email input
            // $request->validate([
            //     'email' => 'required|email',
            // ]);

            $request->validate([
                'email' => [
                    'required',
                    'email',
                    // Conditionally apply the `Rule::unique` only for 'new' type
                    $request->input('type') === 'new' 
                        ? Rule::unique('users', 'email') 
                        : 'sometimes',
                ],
                'type' => ['required', 'in:current,new'], // Ensure type is either 'current' or 'new'
            ]);

            // Generate a 6-digit code
            $code = rand(100000, 999999);

            // Retrieve the user's email and name from the request
            $email = $request->input('email');
            $name = Auth::user()->first_name ?? "Customer"; // Default to "Customer" if no name provided

            // Send the verification code via email
            Mail::to($email)->send(new SendVerificationCode($code, $name));

            // Store the code in the session using the email as the key
            session(["verification_code_{$email}" => $code]);

            return response()->json(['message' => 'Verification code sent successfully.']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Validation failed.',
                'input' => $request->all(),
                'errors' => $e->errors(), // Detailed validation errors
            ], 422);
        } catch (\Exception $e) {
            // Handle email sending error or other exceptions
            return response()->json([
                'message' => 'Failed to send verification code.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function verifyEmailCode(Request $request)
    {
        try {
            // Validate the email and code input
            $request->validate([
                'email' => 'required|email',
                'code' => 'required|digits:6',
            ]);

            $email = $request->input('email');
            $enteredCode = $request->input('code');

            // Retrieve the code from the session using the email key
            $storedCode = session("verification_code_{$email}");

            if ($storedCode && $enteredCode == $storedCode) {
                // Clear the session code after successful verification
                session()->forget("verification_code_{$email}");
                return response()->json(['message' => 'Code validated successfully!']);
            }

            // If the code is invalid or expired
            return response()->json(['message' => 'Invalid or expired code.'], 422);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors(), // Detailed validation errors
            ], 422);
        } catch (\Exception $e) {
            // Handle unexpected errors
            return response()->json([
                'message' => 'An error occurred during verification.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function verifyEmailCodeAndUpdateEmail(Request $request)
    {
        try {
            // Validate the incoming request
        $validatedData = $request->validate([
            'current_email' => 'required|email', // Validate the current email
            'new_email' => 'required|email|unique:users,email', // Validate the new email
        ]);


            // Get the authenticated user
            $user = Auth::user();

            if (!$user) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'User not authenticated.',
                ], 401);
            }

            // Validate the current email matches the user's existing email
            if ($user->email !== $validatedData['current_email']) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'The current email does not match our records.',
                ], 403);
            }

            // Update the user's email to the new email
            $user->email = $validatedData['new_email'];
            $user->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Your email has been updated successfully.',
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed.',
                'errors' => $e->errors(), // Detailed validation errors
            ], 422);
        } catch (\Exception $e) {
            // Handle unexpected errors
            return response()->json([
                'message' => 'An error occurred during verification.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}

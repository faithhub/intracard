<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Card;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class BillingController extends Controller
{
    public function index()
    {
        try {
            $data['dashboard_title'] = "Credit Card";
            // Retrieve the encrypted billing data from the database
            // $billing_details = Billing::where("user_id", Auth::user()->id)->first();

            // // Step 1: Laravel Decryption to retrieve the client-side encrypted data
            // $encrypted_data = Crypt::decrypt($billing_details->encrypted_billing_data);
            // $clientEncryptedData = $encrypted_data['data'];
            // $iv = $encrypted_data['iv'];

            // // Step 2: Client-side Decryption using OpenSSL (ensure you use the correct cipher and key)
            // $cipher = 'aes-256-cbc'; // replace with the actual cipher used for client encryption
            // $key = 'your_client_side_secret_key'; // replace with the actual client-side secret key

            // $decrypted_data = openssl_decrypt($clientEncryptedData, $cipher, $key, OPENSSL_RAW_DATA, $iv);

            // dd($billing_details->encrypted_billing_data, $decrypted_data);
            return view('user.billing', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }

    public function deleteCard(Request $request, $cardId)
    {
        $request->validate([
            'password' => 'required|string',
        ]);

        $user = Auth::user();

        if (!Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Incorrect password.'], 401);
        }

        //Check if the card belongs to user;
        // $card = Card::find($cardId);
        // if (!$card || $card->user_id !== $user->id) {
        //     return response()->json(['message' => 'Card not found or unauthorized access.'], 404);
        // }

        // $card->delete();

        return response()->json(['message' => 'Card deleted successfully.'], 200);
    }

    public function showCards()
    {
        // $cards = Card::where('user_id', Auth::user()->id())
        //     ->get()
        //     ->map(function ($card) {
        //         return [
        //             'id' => $card->id,
        //             'name_on_card' => $card->name_on_card,
        //             'masked_card_number' => '**** **** **** ' . substr($card->card_number, -4), // Masked card number
        //             'expiry_month' => $card->expiry_month,
        //             'expiry_year' => $card->expiry_year,
        //             'is_primary' => $card->is_primary,
        //         ];
        //     });

        // return response()->json($cards);
        //     return view('user.api.cards.index', compact('cards'));

        $dummyCardData = [
            1 => [
                'id' => 1,
                'name' => 'John Doe',
                "type" => "Mastercard",
                "limit" => 1000,    
                'number' => '4111111111111111',
                'expiryMonth' => '12',
                'expiryYear' => '2025',
                'cvv' => '123',
                'is_primary' => true,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
            2 => [
                'id' => 2,
                'name' => 'Jane Smith',
                "type" => "Mastercard",
                "limit" => 1000, 
                'number' => '5500000000000004',
                'expiryMonth' => '9',
                'expiryYear' => '2024',
                'cvv' => '456',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Mastercard'),
            ],
            3 => [
                'id' => 3,
                'name' => 'Marcus Morris',
                "type" => "Visa",
                "limit" => 1000,
                'number' => '340000000000009',
                'expiryMonth' => '6',
                'expiryYear' => '2026',
                'cvv' => '789',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
        ];

        return response()->json($dummyCardData);
    }

    public function getCardDetails($cardId)
    {
        $dummyCardData = [
            1 => [
                'id' => 1,
                'name' => 'John Doe',
                "type" => "Mastercard",
                "limit" => 1000,    
                'number' => '4111111111111111',
                'expiryMonth' => '12',
                'expiryYear' => '2025',
                'cvv' => '123',
                'is_primary' => true,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
            2 => [
                'id' => 2,
                'name' => 'Jane Smith',
                "type" => "Mastercard",
                "limit" => 1000, 
                'number' => '5500000000000004',
                'expiryMonth' => '9',
                'expiryYear' => '2024',
                'cvv' => '456',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Mastercard'),
            ],
            3 => [
                'id' => 3,
                'name' => 'Marcus Morris',
                "type" => "Visa",
                "limit" => 1000,
                'number' => '340000000000009',
                'expiryMonth' => '6',
                'expiryYear' => '2026',
                'cvv' => '789',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
        ];

        // Check if cardId exists in dummy data
        if (!array_key_exists($cardId, $dummyCardData)) {
            return response()->json([
                'message' => 'Card not found',
            ], 404);
        }

        // Return card details
        return response()->json($dummyCardData[$cardId], 200);
    }

    public function getCardDetails2($cardId)
    {
        // try {
        //     // Fetch card details from the database
        //     $card = Card::where('id', $cardId)
        //         ->where('user_id', auth()->id()) // Ensure the card belongs to the authenticated user
        //         ->first();

        //     // Check if the card exists
        //     if (!$card) {
        //         return response()->json([
        //             'message' => 'Card not found or unauthorized access.',
        //         ], 404);
        //     }

        //     // Return the card details as JSON
        //     return response()->json([
        //         'name' => $card->name_on_card,
        //         'number' => $card->masked_card_number, // Ensure to mask the card number (e.g., **** **** **** 1234)
        //         'expiryMonth' => $card->expiry_month,
        //         'expiryYear' => $card->expiry_year,
        //         'cvv' => '***', // CVV should never be sent back for security reasons
        //     ], 200);
        // } catch (Exception $e) {
        //     // Log the exception
        //     \Log::error("Error fetching card details: {$e->getMessage()}");

        //     // Return a generic error response
        //     return response()->json([
        //         'message' => 'An error occurred while fetching the card details. Please try again later.',
        //     ], 500);
        // }
    }

    public function editForm($id)
    {
        // if (!is_numeric($id)) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'Invalid card ID.'
        //     ], 400); // Return 400 status for bad request
        // }
    
        // $card = Card::find($id);
    
        // if (!$card) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'Card not found.'
        //     ], 404);
        // }

        $dummyCardData = [
            1 => [
                'id' => 1,
                'name' => 'John Doe',
                "type" => "Mastercard",
                "limit" => 1000,    
                'number' => '4111111111111111',
                'expiryMonth' => '12',
                'expiryYear' => '2025',
                'cvv' => '123',
                'is_primary' => true,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
            2 => [
                'id' => 2,
                'name' => 'Jane Smith',
                "type" => "Mastercard",
                "limit" => 1000, 
                'number' => '5500000000000004',
                'expiryMonth' => '9',
                'expiryYear' => '2024',
                'cvv' => '456',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Mastercard'),
            ],
            3 => [
                'id' => 3,
                'name' => 'Marcus Morris',
                "type" => "Visa",
                "limit" => 1000,
                'number' => '340000000000009',
                'expiryMonth' => '6',
                'expiryYear' => '2026',
                'cvv' => '789',
                'is_primary' => false,
                'logoUrl' => $this->getCardLogo('Visa'),
            ],
        ];

        // Check if cardId exists in dummy data
        if (!array_key_exists($id, $dummyCardData)) {
            return response()->json([
                'message' => 'Card not found',
            ], 404);
        }

        $card = json_decode(json_encode($dummyCardData[$id]));

        // dd($card);
    
        return view('user.modals.editCard', compact('card'));
    }
    
    public function update(Request $request, $id)
    {
        // Check if the card exists
        // $card = Card::find($id);
    
        // if (!$card) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'Card not found.'
        //     ], 404); // Return 404 status code
        // }
    
        // Validate the input data
        $validator = Validator::make($request->all(), [
            'cardName' => 'required|string|max:255',
            'cardNumber' => 'required|digits:16',
            'expiryDate' => 'required|regex:/^\d{2}\/\d{4}$/', // MM/YYYY format
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422); // 422 Unprocessable Entity
        }
    
        // Update the card details
        // $card->name = $request->input('cardName');
        // $card->number = $request->input('cardNumber');
        // [$month, $year] = explode('/', $request->input('expiryDate'));
        // $card->expiry_month = $month;
        // $card->expiry_year = $year;
        // $card->save();
    
        return response()->json([
            'success' => true,
            'message' => 'Card updated successfully!',
            // 'data' => $card, // Optional: return updated card data
            'data' => [], // Optional: return updated card data
        ]);
    }
    
// Helper method to get card logos
protected function getCardLogo($type)
{
    switch (strtolower($type)) {
        case 'visa':
            return asset('assets/cards/visa.webp');
        case 'mastercard':
            return asset('assets/cards/mastercard.png');
        default:
            return asset('assets/cards/default-card.png');
    }
}
    
    public function wallet()
    {
        try {
            $data['dashboard_title'] = "Wallet";
            return view('user.wallet', $data);
        } catch (\Throwable $th) {
            dd($th);
            //throw $th;
        }
    }
}

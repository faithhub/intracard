<?php

namespace App\Http\Controllers\Auth;

use App\DataSanitizer;
// use App\Http\Requests\RegisterRequest;
use App\Http\Controllers\Controller;
use App\Mail\SendVerificationCode;
use App\Mail\TeamInvitationMail;
use App\Models\Address;
use App\Models\BuildCreditCard;
use App\Models\LandlordFinancerDetail;
use App\Models\Member;
use App\Models\Team;
use App\Models\TeamMember;
use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    use DataSanitizer;
    protected function sendOtpEmail($user, $otpCode)
    {
        Mail::send('emails.otp', ['otpCode' => $otpCode], function ($message) use ($user) {
            $message->to($user->email)
                ->subject('Verify Your Account - OTP Code');
        });
    }

    public function showRegistrationForm()
    {
        // DB::table('settings')->insert([
        //     'key' => 'enable_2fa',
        //     'value' => 'false', // Default value (can be 'true' or 'false')
        //     'type' => 'boolean', // Type of the setting
        //     'created_at' => now(),
        //     'updated_at' => now(),
        // ]);
        try {
            //code...
            // Show the registration form (GET request)
            // return view('auth.reg4');
            return view('auth.register', [
                'pageTitle' => 'Intracard | Sign Up',
            ]);
        } catch (\Throwable $th) {
            dd($th->getMessage());
            //throw $th;
        }
    }

    public function checkEmailExists(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $emailExists = User::where('email', $request->email)->exists();

        if ($emailExists) {
            return response()->json(['status' => 'error', 'message' => 'Email already exists.'], 409); // 409 Conflict
        }

        return response()->json(['status' => 'success', 'message' => 'Email is available.'], 200);
    }

    public function register2(Request $request)
    {

        // Validate user and address details (add specific rules as needed)
        $validator = Validator::make($request->all(), [
            'personalDetails.firstName' => 'required|string|max:50',
            'personalDetails.lastName' => 'required|string|max:50',
            'personalDetails.middleName' => 'nullable|string|max:50',
            'personalDetails.email' => 'required|email|unique:users,email',
            'personalDetails.phone' => 'required|string|max:15',
            // Other accountType and address validation rules

            // Validate Account Type Details
            'accountType.goal' => 'required|string|in:rent,mortgage',
            'accountType.plan' => 'nullable|string|in:pay_rent,pay_rent_build,pay_mortgage,pay_mortgage_build',
            'accountType.applicationType' => 'nullable|string|in:sole_applicant,co_applicant,owner,co_owner',
            'accountType.paymentSetup' => 'nullable|string|in:Continue_paying_existing_rent,Setup_payment_new_rental,Continue_paying_existing_mortgage,Setup_payment_new_mortgage',
            'accountType.creditCardLimit' => 'nullable|numeric|min:100|max:500000',
            'accountType.creditCardDueDate' => 'nullable|integer|min:1|max:31',

            // Validate Primary Rent/Mortgage Amount (for Co-Applicants or Co-Owners)
            'accountType.primaryRentOrMortgageAmount' => 'nullable|numeric|min:100|max:500000',

            // Validate Co-Applicants (if any)
            'accountType.coApplicants' => 'array',
            'accountType.coApplicants.*.firstName' => 'required_with:accountType.coApplicants|string|max:50',
            'accountType.coApplicants.*.lastName' => 'required_with:accountType.coApplicants|string|max:50',
            'accountType.coApplicants.*.email' => 'required_with:accountType.coApplicants|email',
            // 'accountType.coApplicants.*.mortgageAmount' => 'required_with:accountType.coApplicants|numeric|min:100|max:500000',

            // Validate Landlord or Mortgage Finance Details
            'landlordOrFinanceDetails.paymentMethod' => 'nullable|string|in:interac,cheque,EFT,ACH',
            'landlordOrFinanceDetails.email' => 'nullable|email|required_if:landlordOrFinanceDetails.paymentMethod,interac',

            // // Bank Details for EFT and ACH
            // 'landlordOrFinanceDetails.bankDetails' => 'nullable|array',
            // 'landlordOrFinanceDetails.bankDetails.bankName' => 'required_if:landlordOrFinanceDetails.paymentMethod,EFT|string|max:50',
            // 'landlordOrFinanceDetails.bankDetails.accountNumber' => 'required_if:landlordOrFinanceDetails.paymentMethod,EFT|numeric',
            // 'landlordOrFinanceDetails.bankDetails.routingNumber' => 'required_if:landlordOrFinanceDetails.paymentMethod,EFT|numeric',
            // 'landlordOrFinanceDetails.bankDetails.accountType' => 'required_if:landlordOrFinanceDetails.paymentMethod,EFT|string|in:Checking,Savings',
            // 'landlordOrFinanceDetails.bankDetails.bankRoutingNumber' => 'required_if:landlordOrFinanceDetails.paymentMethod,ACH|numeric',
            // 'landlordOrFinanceDetails.bankDetails.recipientName' => 'required_if:landlordOrFinanceDetails.paymentMethod,ACH|string|max:50',
            // 'landlordOrFinanceDetails.bankDetails.accountNumber' => 'required_if:landlordOrFinanceDetails.paymentMethod,ACH|numeric',
            // 'landlordOrFinanceDetails.bankDetails.accountType' => 'required_if:landlordOrFinanceDetails.paymentMethod,ACH|string|in:Checking,Savings',
            // 'landlordOrFinanceDetails.bankDetails.individualOrBusiness' => 'required_if:landlordOrFinanceDetails.paymentMethod,ACH|string|in:individual,business',

            // // Landlord Type Details
            // 'landlordOrFinanceDetails.landlordType' => 'nullable|string|in:business,individual',
            // 'landlordOrFinanceDetails.landlordInfo.businessName' => 'required_if:landlordOrFinanceDetails.landlordType,business|string|max:100',
            // 'landlordOrFinanceDetails.landlordInfo.firstName' => 'required_if:landlordOrFinanceDetails.landlordType,individual|string|max:50',
            // 'landlordOrFinanceDetails.landlordInfo.lastName' => 'required_if:landlordOrFinanceDetails.landlordType,individual|string|max:50',
            // 'landlordOrFinanceDetails.landlordInfo.middleName' => 'nullable|string|max:50',

            // //Address
            // 'addressDetails.address' => 'required|string|max:255',
            // 'addressDetails.province' => 'required|string|max:100',
            // 'addressDetails.city' => 'required|string|max:100',
            // 'addressDetails.postalCode' => 'required|string|max:10',
            // 'addressDetails.unitNumber' => 'nullable|string|max:10',
            // 'addressDetails.houseNumber' => 'nullable|string|max:10',
            // 'addressDetails.streetName' => 'nullable|string|max:255',
            // 'addressDetails.rentAmount' => 'required|numeric|min:100|max:50000',
            // 'addressDetails.tenancyAgreement' => 'required|file|mimes:pdf,jpg,jpeg,png|max:10240', // Max 10MB
            // 'addressDetails.reOccurringMonthlyDay' => 'required|integer|min:1|max:31',
            // 'addressDetails.duration.from' => 'required|date|before_or_equal:addressDetails.duration.to',
            // 'addressDetails.duration.to' => 'required|date|after_or_equal:addressDetails.duration.from',

            // Validate Billing Info (Client-side encrypted)
            'billingInfo.data' => 'required|string',
            'billingInfo.iv' => 'required|string',
        ]);

        // If validation fails, return error response
        if ($validator->fails()) {
            return response()->json(['status' => 'error', 'errors' => $validator->errors()], 422);
        }

        // Handle Tenancy Agreement File Upload
        $tenancyAgreementPath = null;
        if ($request->hasFile('tenancy_agreement')) {
            $tenancyAgreementPath = $request->file('tenancy_agreement')->store('public/tenancy_agreements');
        }

        // Decode and decrypt client-side encrypted billing data
        $clientEncryptedData = base64_decode($request->input('billingInfo.data'));
        $iv = base64_decode($request->input('billingInfo.iv'));

        // Optionally re-encrypt with Laravel's Crypt for an additional layer of security
        $encryptedBillingInfo = Crypt::encrypt([
            'data' => $clientEncryptedData,
            'iv' => $iv,
        ]);

        // Begin a transaction to save user and billing data
        DB::beginTransaction();

        try {
            $addressDetails = $request->input('accountType'); // This is already an array

            // Now access the 'goal' field
            $goal = $addressDetails['goal']; // Access the 'goal' field directly
            // Save user details
            $user = User::create([
                'first_name' => e($request->input('personalDetails.firstName')),
                'password' => e($request->input('personalDetails.password')),
                'last_name' => e($request->input('personalDetails.lastName')),
                'middle_name' => e($request->input('personalDetails.middleName')),
                'email' => e($request->input('personalDetails.email')),
                'phone' => e($request->input('personalDetails.phone')),
                'status' => 'active', // Default status
                'account_type' => e($request->input('accountType.goal')), // Store account type as JSON
                'account_details' => json_encode($request->input('accountType')), // Store account type as JSON
                'address_details' => json_encode($request->input('addressDetails')), // Store account type as JSON
                'landlord_or_finance_details' => json_encode($request->input('getLandlordOrFinanceDetails')), // Store landlord or finance details as JSON
                // Other user attributes as needed
            ]);
            // Check if applicationType is "Co-applicant" or "Co-owner"
            if (in_array($request->input('accountType.applicationType'), ['co_applicant', 'co_owner'])) {
                // Create a team for the user
                $team = Team::create([
                    'name' => $goal, // Automatically encrypted
                    'admin_id' => $user->id,
                ]);

                // Add the admin as a member of the team
                Member::create([
                    'team_id' => $team->id,
                    'user_id' => $user->id,
                    'first_name' => $user->first_name, // Automatically encrypted
                    'last_name' => $user->last_name, // Automatically encrypted
                    'email' => $user->email, // Automatically encrypted
                ]);

                // Add co-applicants as members of the team
                $coApplicants = $request->input('accountType.coApplicants');
                if (!empty($coApplicants)) {
                    foreach ($coApplicants as $coApplicant) {
                        Member::create([
                            'team_id' => $team->id,
                            'user_id' => null, // Co-applicants may not be registered users
                            'first_name' => $coApplicant['firstName'], // Automatically encrypted
                            'last_name' => $coApplicant['lastName'], // Automatically encrypted
                            'email' => $coApplicant['email'], // Automatically encrypted
                        ]);
                    }
                }
            }

            // Commit the transaction
            DB::commit();

            // Return success response
            return response()->json([
                'status' => 'success',
                'data' => $request->input('accountType'),
                'message' => 'User and double-encrypted billing information saved successfully',
            ], 201);

        } catch (\Exception $e) {
            \Log::info('Co-Applicants:', $request->input('accountType.coApplicants'));
            \Log::info('accountType:', $request->input('accountType'));
            \Log::error('Registration Error: ' . $e->getMessage());
            // Rollback on any failure
            DB::rollBack();
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to save information',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    protected function sendTeamInvitationEmail($email, $team, $admin)
    {
        $details = [
            'team_name' => $team->name,
            'admin_name' => "{$admin->first_name} {$admin->last_name}",
            'admin_email' => $admin->email,
        ];

        Mail::to($email)->send(new TeamInvitationMail($details));
    }

    protected function saveRelatedData(User $user, array $data)
    {
        function mapPaymentMethod($input)
        {
            $mapping = [
                'mortgage_cheque' => 'cheque',
                'EFT' => 'EFT',
                'landlord_account_mode' => 'interac',
                'landlord_account_cheque' => 'cheque',
            ];

            return $mapping[$input] ?? 'cheque'; // Default to 'cheque' if input doesn't match
        }
        // Create a wallet for the user
        Wallet::create([
            'user_id' => $user->id,
            'balance' => 0.00, // Initial balance
            'details' => json_encode(['created_at' => now()]), // Optional details
        ]);

        // Save Team
        if (!empty($data['coApplicants'])) {
            $team = Team::create([
                'user_id' => $user->id,
                'name' => $data['accountType']['plan'] ?? 'Default Team Name',
                'members' => json_encode($data['accountType']['coApplicants']), // Store co-applicants in JSON format
            ]);

            // Add admin (current user) as a team member
            TeamMember::create([
                'team_id' => $team->id,
                'name' => "{$user->first_name} {$user->last_name}",
                'email' => $user->email,
                'status' => 'accepted',
                'role' => 'admin',
                'amount' => $data['primaryRentOrMortgageAmount'] ?? 0, // Admin's rent amount
            ]);

            // Add co-applicants as team members
            foreach ($data['accountType']['coApplicants'] as $applicant) {
                TeamMember::create([
                    'team_id' => $team->id,
                    'name' => "{$applicant['firstName']} {$applicant['lastName']}",
                    'email' => $applicant['email'],
                    'status' => 'pending', // Pending status since invitation is sent
                    'role' => 'member',
                    'amount' => $applicant['rentAmount'] ?? 0, // Rent amount from the applicant
                ]);

                // Send email to co-applicant
                $this->sendTeamInvitationEmail($applicant['email'], $team, $user);
            }
        }

        // Save address data if available
        if (!empty($data['addressDetails'])) {
            $address = Address::create([
                'user_id' => $user->id,
                'name' => $data['addressDetails']['address'] ?? null,
                'city' => $data['addressDetails']['city'] ?? null,
                'province' => $data['addressDetails']['province'] ?? null,
                'postal_code' => $data['addressDetails']['postalCode'] ?? null,
                'house_number' => $data['addressDetails']['houseNumber'] ?? null,
                'unit_number' => $data['addressDetails']['unitNumber'] ?? null,
                'street_name' => $data['addressDetails']['streetName'] ?? null,
                'amount' => $data['addressDetails']['rentAmount'] ?? 0,
                'reoccurring_monthly_day' => $data['reOccurringMonthlyDay'] ?? null,
                'duration_from' => $data['addressDetails']['duration']['from'] ?? null,
                'duration_to' => $data['addressDetails']['duration']['to'] ?? null,
                'tenancy_agreement' => $data['tenancyAgreement'] ?? null, // Assume file upload handling
            ]);

            function generateLandlordDetails($data)
            {
                $paymentMethod = mapPaymentMethod($data['accountType']['paymentSetup'] ?? 'cheque');
                $type = $data['accountType']['goal'] ?? 'rent';
                $landlordType = $data['getLandlordOrFinanceDetails']['landlordType'] ?? 'individual';

                // Mortgage Cheque Details
                if ($paymentMethod === 'cheque' && $type === 'mortgage') {
                    return json_encode([
                        'accountNumber' => $data['getLandlordOrFinanceDetails']['mortgageChequeDetails']['accountNumber'] ?? null,
                        'transitNumber' => $data['getLandlordOrFinanceDetails']['mortgageChequeDetails']['transitNumber'] ?? null,
                        'institutionNumber' => $data['getLandlordOrFinanceDetails']['mortgageChequeDetails']['institutionNumber'] ?? null,
                        'name' => $data['getLandlordOrFinanceDetails']['mortgageChequeDetails']['name'] ?? null,
                        'address' => $data['getLandlordOrFinanceDetails']['mortgageChequeDetails']['address'] ?? null,
                        'paymentMethod' => $paymentMethod,
                    ]);
                }

                // Mortgage EFT Details
                if ($paymentMethod === 'EFT' && $type === 'mortgage') {
                    return json_encode([
                        'institutionNumber' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['institutionNumber'] ?? null,
                        'transitNumber' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['transitNumber'] ?? null,
                        'accountNumber' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['accountNumber'] ?? null,
                        'bankAccountNumber' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['bankAccountNumber'] ?? null,
                        'biWeeklyDueDate' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['biWeeklyDueDate'] ?? null,
                        'lenderAddress' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['lenderAddress'] ?? null,
                        'lenderName' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['lenderName'] ?? null,
                        'paymentFrequency' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['paymentFrequency'] ?? null,
                        'refNumber' => $data['getLandlordOrFinanceDetails']['mortgageEftDetails']['refNumber'] ?? null,
                    ]);
                }

                // Rent Interac Details
                if ($paymentMethod === 'interac' && $type === 'rent') {
                    return json_encode([
                        'email' => $data['getLandlordOrFinanceDetails']['email'] ?? null,
                    ]);
                }

                // Rent Cheque Details for Business
                if ($paymentMethod === 'cheque' && $type === 'rent' && $landlordType === 'business') {
                    return json_encode([
                        'businessName' => $data['getLandlordOrFinanceDetails']['landlordInfo']['businessName'] ?? null,
                    ]);
                }

                // Rent Cheque Details for Individual
                if ($paymentMethod === 'cheque' && $type === 'rent' && $landlordType === 'individual') {
                    return json_encode([
                        'firstName' => $data['getLandlordOrFinanceDetails']['landlordInfo']['firstName'] ?? null,
                        'lastName' => $data['getLandlordOrFinanceDetails']['landlordInfo']['lastName'] ?? null,
                        'middleName' => $data['getLandlordOrFinanceDetails']['landlordInfo']['middleName'] ?? null,
                    ]);
                }
                // Default fallback
                return json_encode([]);
            }

            // Save financial details if address is created
            if ($address) {
                LandlordFinancerDetail::create([
                    'address_id' => $address->id,
                    'type' => $data['accountType']['goal'] ?? 'rent', // Rent or mortgage
                    'payment_method' => mapPaymentMethod($data['accountType']['paymentSetup'] ?? 'cheque'), // Map payment method
                    'landlord_type' => $data['getLandlordOrFinanceDetails']['landlordType'] ?? 'individual', // Landlord type
                    'details' => generateLandlordDetails($data), // Generate the dynamic JSON details
                ]);
            }
        }

        // Save credit card data if available
        if (!empty($data['accountType']['creditCardLimit']) && !empty($data['accountType']['creditCardDueDate'])) {
            BuildCreditCard::create([
                'card_id' => $data['card_id'] ?? null, // Pass this from the request or logic
                'user_id' => $user->id,
                'cc_limit' => $data['accountType']['creditCardLimit'], // Credit card limit
                'cc_due_date' => $data['accountType']['creditCardDueDate'], // Credit card due date (day of the month)
            ]);
        }

        // Save additional related data as needed...
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'personalDetails.firstName' => 'required|string|max:50',
            'personalDetails.lastName' => 'required|string|max:50',
            'personalDetails.middleName' => 'nullable|string|max:50',
            'personalDetails.email' => 'required|email|unique:users,email',
            'personalDetails.phone' => 'required|string|max:15',
            'accountType.goal' => 'required|string|in:rent,mortgage',
            'accountType.applicationType' => 'nullable|string|in:sole_applicant,co_applicant,owner,co_owner',
            'accountType.coApplicants' => 'nullable|array',
            'accountType.coApplicants.*.firstName' => 'required_with:accountType.coApplicants|string|max:50',
            'accountType.coApplicants.*.lastName' => 'required_with:accountType.coApplicants|string|max:50',
            'accountType.coApplicants.*.email' => 'required_with:accountType.coApplicants|email',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 'error', 'errors' => $validator->errors()], 422);
        }

        DB::beginTransaction();

        // Sanitize all input data
        $data = $this->sanitizeData($request->all());

        function mapPaymentSetup($input)
        {
            $mapping = [
                'Continue_paying_existing_mortgage' => 'new',
                'Continue_paying_existing_rent' => 'new',
                'Setup_payment_new_mortgage' => 'existing',
                'Setup_payment_new_rental' => 'existing',
            ];

            return $mapping[$input] ?? 'new';
        }
        $paymentSetup = mapPaymentSetup($data['accountType']['paymentSetup']);

        try {
            // Define array_map_recursive function
            // $data = $request->all();

            // Now access the 'goal' field
            $user = User::create([
                'first_name' => $data['personalDetails']['firstName'],
                'last_name' => $data['personalDetails']['lastName'] ?? null,
                'middle_name' => $data['personalDetails']['middleName'],
                'email' => $data['personalDetails']['email'],
                'phone' => $data['personalDetails']['phone'],
                'password' => $data['personalDetails']['password'], // Hash password
                'account_goal' => $data['accountType']['goal'],
                'account_type' => $data['accountType']['applicationType'] ?? null,
                'payment_setup' => $paymentSetup,
                'status' => 'pending', // Set the default status or use the input
            ]);

            // Save related data
            $this->saveRelatedData($user, $data);

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User registered successfully.',
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Registration Error:', ['error' => $e->getMessage()]);
            return response()->json([
                'status' => 'error',
                'data' => $request->all(),
                'message' => 'Failed to save information',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function verifyOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'otp_code' => 'required|string',
        ]);

        // Find the user by email
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['message' => 'User not found.'], 404);
        }

        // Check if the OTP is correct and not expired
        if ($user->otp_code !== $request->otp_code) {
            return response()->json(['message' => 'Invalid OTP.'], 400);
        }

        if (Carbon::now()->greaterThan($user->otp_expires_at)) {
            return response()->json(['message' => 'OTP has expired.'], 400);
        }

        // Mark the user as verified
        $user->is_verified = true;
        $user->otp_code = null; // Clear OTP
        $user->otp_expires_at = null;
        $user->save();

        return response()->json(['message' => 'Account verified successfully!'], 200);
    }

    public function sendEmailVerificationCode(Request $request)
    {
        try {
            // Validate the email input
            $request->validate([
                'email' => 'required|email',
                'name' => 'nullable|string',
            ]);

            // Generate a 6-digit code
            $code = rand(100000, 999999);

            // Retrieve the user's email and name from the request
            $email = $request->input('email');
            $name = $request->input('name', 'Customer'); // Default to "Customer" if no name provided

            // Send the verification code via email
            Mail::to($email)->send(new SendVerificationCode($code, $name));

            // Store the code in the session using the email as the key
            session(["verification_code_{$email}" => $code]);

            return response()->json(['message' => 'Verification code sent successfully.']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Invalid input.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            // Handle email sending error or other exceptions
            return response()->json([
                'message' => 'Failed to send verification code.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function verifyEmailCode(Request $request)
    {
        try {
            // Validate the email and code input
            $request->validate([
                'email' => 'required|email',
                'code' => 'required|digits:6',
            ]);

            $email = $request->input('email');
            $enteredCode = $request->input('code');

            // Retrieve the code from the session using the email key
            $storedCode = session("verification_code_{$email}");

            if ($storedCode && $enteredCode == $storedCode) {
                // Clear the session code after successful verification
                session()->forget("verification_code_{$email}");
                return response()->json(['message' => 'Code validated successfully!']);
            }

            // If the code is invalid or expired
            return response()->json(['message' => 'Invalid or expired code.'], 422);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Invalid input.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            // Handle unexpected errors
            return response()->json([
                'message' => 'An error occurred during verification.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function getCities($province)
    {
        // Validate the province parameter to prevent SQL injection
        if (!$province) {
            return response()->json(['error' => 'Province is required'], 400);
        }

        // Query the cities based on the selected province
        $cities = DB::table('cities')
            ->where('province_name', $province)
            ->pluck('city');

        return response()->json($cities);
    }

    public function sendPhoneVerificationCode(Request $request)
    {
        try {
            // Validate phone number format
            $request->validate([
                'phone' => 'required|string|', // Canadian phone number with +1 code
            ]);

            // Generate a 6-digit verification code
            $code = rand(100000, 999999);
            $phone = $request->input('phone');

            // Store the code in the session using the phone number as the key
            Session::put("verification_code_{$phone}", $code);

            // Send the code via Twilio
            // $twilio = new Client(env('TWILIO_SID'), env('TWILIO_AUTH_TOKEN'));

            // $twilio->messages->create($phone, [
            //     'from' => env('TWILIO_PHONE_NUMBER'),
            //     'body' => "Your CrediPay verification code is: $code",
            // ]);

            return response()->json(['message' => 'Verification code sent successfully.']);
        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Invalid phone number format.',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Twilio\Exceptions\RestException $e) {
            // Handle Twilio API errors
            return response()->json([
                'message' => 'Failed to send SMS via Twilio.',
                'error' => $e->getMessage(),
            ], 500);
        } catch (\Throwable $th) {
            // Handle any other errors
            return response()->json([
                'message' => 'An unexpected error occurred while sending the verification code.',
                'error' => $th->getMessage(),
            ], 500);
        }
    }

    public function verifyPhoneCode(Request $request)
    {
        try {
            // Validate phone number and code format
            $request->validate([
                'phone' => 'required|string|', // Canadian phone number with +1 code
                'code' => 'required|digits:6',
            ]);

            $phone = $request->input('phone');
            $enteredCode = $request->input('code');
            $storedCode = Session::get("verification_code_{$phone}");

            if ($storedCode && $enteredCode == $storedCode) {
                // Clear the code from the session upon successful verification
                Session::forget("verification_code_{$phone}");
                return response()->json(['message' => 'Phone number verified successfully!']);
            }

            // If code doesn't match or isn't found, return an error
            return response()->json(['storedCode' => $storedCode, 'enteredCode' => $enteredCode, 'message' => 'Invalid or expired verification code.'], 422);

        } catch (\Illuminate\Validation\ValidationException $e) {
            // Handle validation error
            return response()->json([
                'message' => 'Validation failed.',
                'errors' => $e->errors(),
            ], 422);

        } catch (\Throwable $th) {
            // Handle any other unexpected errors
            return response()->json([
                'message' => 'An unexpected error occurred during verification.',
                'error' => $th->getMessage(),
            ], 500);
        }
    }

    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->update(['status' => 'deleted']);

        return response()->json([
            'success' => true,
            'message' => 'User marked as deleted.',
        ]);
    }

    public function restoreUser($id)
    {
        $user = User::where('id', $id)->where('status', 'deleted')->firstOrFail();
        $user->update(['status' => 'active']);

        return response()->json([
            'success' => true,
            'message' => 'User restored successfully.',
        ]);
    }

    public function getUsersByStatus($status)
    {
        $users = User::where('status', $status)->get();

        return response()->json($users);
    }

}

<template>
    <div class="modal" id="setupBillModal">
        <!-- Setup Bill Modal Content -->
    </div>
</template>

<script>
export default {
    name: "SetupBillModal",
};
</script>

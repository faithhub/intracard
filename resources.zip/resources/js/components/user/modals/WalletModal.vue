<template>
    <div class="modal" id="walletModal">
        <!-- Wallet Modal Content -->
    </div>
</template>

<script>
export default {
    name: "WalletModal",
};
</script>

<template>
    <div class="profile">
        <h1 class="mb-4">My Profile</h1>

        <div class="card p-4">
            <form @submit.prevent="updateProfile">
                <!-- Name Field -->
                <div class="form-group mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input
                        id="name"
                        v-model="form.name"
                        type="text"
                        class="form-control"
                        placeholder="Enter your name"
                        required
                    />
                </div>

                <!-- Email Field -->
                <div class="form-group mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input
                        id="email"
                        v-model="form.email"
                        type="email"
                        class="form-control"
                        placeholder="Enter your email"
                        required
                        disabled
                    />
                    <small class="text-muted">Your email address cannot be changed.</small>
                </div>

                <!-- Password Change Field -->
                <div class="form-group mb-3">
                    <label for="password" class="form-label">New Password</label>
                    <input
                        id="password"
                        v-model="form.password"
                        type="password"
                        class="form-control"
                        placeholder="Enter a new password (optional)"
                    />
                </div>

                <!-- Update Button -->
                <button type="submit" class="btn btn-primary" :disabled="loading">
                    <span v-if="!loading">Update Profile</span>
                    <span v-else>
                        Saving...
                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                </button>
            </form>
        </div>
    </div>
</template>

---

### **Script Section**

```javascript
<script>
import { useToast } from "vue-toastification";
import axios from "@/utils/axios";// Assuming your custom Axios instance is exported from axios.js

export default {
    name: "Profile",
    data() {
        return {
            form: {
                name: "",
                email: "",
                password: "",
            },
            loading: false,
        };
    },
    methods: {
        async fetchProfile() {
            try {
                const response = await axios.get("/api/user/profile"); // Replace with your API endpoint
                this.form.name = response.data.name;
                this.form.email = response.data.email;
            } catch (error) {
                console.error("Error fetching profile:", error);
            }
        },
        async updateProfile() {
            const toast = useToast();
            this.loading = true;

            try {
                const response = await axios.put("/api/user/profile", this.form); // Replace with your API endpoint
                toast.success("Profile updated successfully!", { timeout: 3000 });
            } catch (error) {
                toast.error(
                    error.response?.data?.message || "Failed to update profile.",
                    { timeout: 5000 }
                );
            } finally {
                this.loading = false;
            }
        },
    },
    mounted() {
        this.fetchProfile();
    },
};
</script>

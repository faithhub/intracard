<template>
    <v-row>
        <!-- Welcome Text and Setup Bill Button -->
        <v-col cols="12">
            <v-row>
                <!-- Calendar Card -->
                <v-col cols="12" md="12">
                    <v-card class="calendar-card pa-4 rounded-3" elevation="10">
                        <!-- <v-card-title class="text-h3 font-weight-bold mb-4 lt-sp">My Cards</v-card-title> -->

                        <!-- Credit Card and Transactions Section -->
                        <section class="credit-card-section">
                            <div class="py-5 p-5">
                                <!-- Credit Cards -->
                                <div class="d-flex justify-space-between align-items-center mb-4">
                                    <h3 class="section-title">My Credit Cards</h3>
                                </div>
                                <div class="card-body mb-8 mb-xl-12">

                                    <div v-if="loading">Loading cards...</div>
                                    <div v-else>
                                        <div class="row gx-9 gy-6">
                                            <div v-for="card in cards" :key="card.id" class="col-xl-6"
                                                data-kt-billing-element="card" :data-card-id="card.id">
                                                <!--begin::Card-->
                                                <div
                                                    class="card card-dashed h-xl-100 flex-row flex-stack flex-wrap p-6">
                                                    <!--begin::Info-->
                                                    <div class="d-flex flex-column py-2">
                                                        <!--begin::Owner-->
                                                        <div class="d-flex align-items-center fs-4 fw-bold mb-5">
                                                            {{ card.name }}
                                                            <span class="badge badge-light-success fs-7 ms-2"
                                                                v-if="card.is_primary">
                                                                Primary
                                                            </span>
                                                        </div>
                                                        <!--end::Owner-->
                                                        <!--begin::Wrapper-->
                                                        <div class="d-flex align-items-center">
                                                            <!--begin::Icon-->
                                                            <img src="@assets/cards/mastercard.png" alt="Card Icon"
                                                                class="me-4" style="width:50px">
                                                            <!--end::Icon-->
                                                            <!--begin::Details-->
                                                            <div>
                                                                <div class="fs-4 fw-bold">**** **** **** {{
                                                                    card.number.slice(-4) }}</div>
                                                                <div class="fs-6 fw-semibold text-gray-500">
                                                                    Card expires at {{ card.expiryMonth }}/{{
                                                                        card.expiryYear }}
                                                                </div>
                                                            </div>
                                                            <!--end::Details-->
                                                        </div>
                                                        <!--end::Wrapper-->
                                                    </div>
                                                    <!--end::Info-->
                                                    <!--begin::Actions-->
                                                    <div class="d-flex align-items-center py-2">
                                                        <button
                                                            class="btn btn-sm btn-light btn-active-light-primary me-3"
                                                            @click="confirmDeleteCard(card.id)">
                                                            Delete
                                                        </button>
                                                        <!-- <button class="btn btn-sm btn-light btn-active-light-primary"
                                                            @click="editCardModal(card.id)">
                                                            Edit
                                                        </button> -->
                                                    </div>
                                                    <!--end::Actions-->
                                                </div>
                                                <!--end::Card-->
                                            </div>

                                            <div class="col-xl-6">
                                                <!--begin::Notice-->
                                                <div class="notice d-flex bg-light-primary border-primary border border-dashed h-lg-100 p-6"
                                                    style="background-color: #a000f900 !important">
                                                    <!--begin::Wrapper-->
                                                    <div class="d-flex flex-stack flex-grow-1 flex-wrap flex-md-nowrap">
                                                        <!--begin::Content-->
                                                        <div class="mb-3 mb-md-0 fw-semibold">
                                                            <h4 class="text-gray-900 fw-bold">Important Note!</h4>
                                                            <div class="fs-6 text-gray-700 pe-7">Please carefully read
                                                                <a href="#" class="fw-bold me-1">Product Terms</a>
                                                                adding
                                                                <br> your new payment card
                                                            </div>
                                                        </div>
                                                        <!--end::Content-->
                                                        <button
                                                            class="btn btn-primary px-6 align-self-center text-nowrap"
                                                            @click="toggleAddCardModal">Add Card</button>
                                                    </div>
                                                    <!--end::Wrapper-->
                                                </div>
                                                <!--end::Notice-->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Transactions -->
                                <div class="card mb-5 mb-xl-12">
                                    <!--begin::Card header-->
                                    <div class="card-header card-header-stretch pb-0">
                                        <!--begin::Title-->
                                        <div class="card-title">
                                            <h3 class="m-0">Transactions</h3>
                                        </div>
                                    </div>

                                    <div class="card-body pt-0">
                                        <div id="kt_customers_table_wrapper"
                                            class="dt-container dt-bootstrap5 dt-empty-footer">
                                            <div id="" class="table-responsive">
                                                <table class="table align-middle table-row-dashed fs-6 gy-5 dataTable"
                                                    id="kt_customers_table" style="width: 100%;">
                                                    <colgroup>
                                                        <col data-dt-column="0" style="width: 36.3906px;">
                                                        <col data-dt-column="1" style="width: 132.766px;">
                                                        <col data-dt-column="2" style="width: 166.844px;">
                                                        <col data-dt-column="3" style="width: 191.25px;">
                                                        <col data-dt-column="4" style="width: 140.078px;">
                                                        <col data-dt-column="5" style="width: 177.438px;">
                                                        <col data-dt-column="6" style="width: 111.734px;">
                                                    </colgroup>
                                                    <thead>
                                                        <tr class="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0"
                                                            role="row">
                                                            <th class="w-10px pe-2 dt-orderable-none" data-dt-column="0"
                                                                rowspan="1" colspan="1" aria-label="">
                                                                <span class="dt-column-title">
                                                                    <div
                                                                        class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                                        <input class="form-check-input" type="checkbox"
                                                                            data-kt-check="true"
                                                                            data-kt-check-target="#kt_customers_table .form-check-input"
                                                                            value="1">
                                                                    </div>
                                                                </span>
                                                                <span class="dt-column-order"></span>
                                                            </th>
                                                            <th class="min-w-125px dt-orderable-asc dt-orderable-desc"
                                                                data-dt-column="1" rowspan="1" colspan="1"
                                                                aria-label="Customer Name: Activate to sort"
                                                                tabindex="0"><span class="dt-column-title"
                                                                    role="button">Transaction ID</span><span
                                                                    class="dt-column-order"></span></th>
                                                            <th class="min-w-125px dt-orderable-asc dt-orderable-desc"
                                                                data-dt-column="2" rowspan="1" colspan="1"
                                                                aria-label="Email: Activate to sort" tabindex="0"><span
                                                                    class="dt-column-title"
                                                                    role="button">Amount</span><span
                                                                    class="dt-column-order"></span></th>
                                                            <th class="min-w-125px dt-orderable-asc dt-orderable-desc"
                                                                data-dt-column="4" rowspan="1" colspan="1"
                                                                aria-label="Payment Method: Activate to sort"
                                                                tabindex="0"><span class="dt-column-title" role="button"
                                                                    id="tableCardType">Credit Card</span><span
                                                                    class="dt-column-order"></span></th>
                                                            <th class="min-w-125px dt-orderable-asc dt-orderable-desc"
                                                                data-dt-column="5" rowspan="1" colspan="1"
                                                                aria-label="Created Date: Activate to sort"
                                                                tabindex="0"><span class="dt-column-title"
                                                                    role="button">Date</span><span
                                                                    class="dt-column-order"></span></th>
                                                            <th class="text-end min-w-70px dt-orderable-none"
                                                                data-dt-column="6" rowspan="1" colspan="1"
                                                                aria-label="Actions"><span
                                                                    class="dt-column-title">Actions</span><span
                                                                    class="dt-column-order"></span></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody class="fw-semibold text-gray-600">
                                                        <tr>
                                                            <td>
                                                                <div
                                                                    class="form-check form-check-sm form-check-custom form-check-solid">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="1">
                                                                </div>
                                                            </td>
                                                            <td>
                                                                #DFSGDFHGGFDJHGF
                                                            </td>
                                                            <td>
                                                                $500.00
                                                            </td>
                                                            <td data-filter="visa">
                                                                <img src="https://c.webcyborg.com.ng/public/assets/cards/mastercard.png"
                                                                    class="w-35px me-3" alt="">
                                                                **** 3215
                                                            </td>
                                                            <td data-order="2020-08-18T15:34:00+01:00">
                                                                18 Aug 2020, 3:34 pm
                                                            </td>
                                                            <td class="text-end">
                                                                <!-- <a href="#" class="menu-link px-3">View</a> -->
                                                                <button
                                                                    class="btn btn-sm btn-light btn-active-light-primary px-3"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_new_card">View</button>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </v-card>
                </v-col>

            </v-row>
        </v-col>
    </v-row>
    <!-- Modal Add-->
    <transition name="fade">
        <div v-if="isAddCardModalOpen" class="modal-overlay">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h2>Add New Card</h2>
                        <div class="btn btn-sm btn-icon btn-active-color-primary" @click="toggleAddCardModal">
                            <i class="fa fa-xmark fs-1"></i>
                        </div>
                    </div>
                    <!-- Modal Body -->
                    <div class="modal-body mx-5 mx-xl-15 my-7">
                        <form @submit.prevent="validateAndSubmitAddCard" novalidate>
                            <!-- Name on Card -->
                            <div class="d-flex flex-column mb-7 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                                    <span class="required">Name On Card</span>
                                    <span class="ms-1" data-bs-toggle="tooltip" title="Specify a card holder's name">
                                        <i class="fa fa-exclamation text-gray-500"></i>
                                    </span>
                                </label>
                                <input type="text" class="form-control form-control-solid" placeholder="Cardholder Name"
                                    v-model="newCard.name" @input="clearErrorAndValidate('name', validateName)"
                                    required />
                                <small v-if="addErrors.name" class="text-danger">{{ addErrors.name }}</small>
                            </div>

                            <!-- Card Number -->
                            <div class="d-flex flex-column mb-7 fv-row">
                                <label class="required fs-6 fw-semibold form-label mb-2">Card Number</label>
                                <div class="position-relative">
                                    <input type="text" class="form-control form-control-solid"
                                        placeholder="Enter card number" v-model="newCard.number"
                                        @input="clearErrorAndValidate('number', validateCardNumber)" maxlength="19"
                                        required />
                                    <div class="position-absolute translate-middle-y top-50 end-0 me-5">
                                        <img src="" alt="" class="h-25px" />
                                        <img src="" alt="" class="h-25px" />
                                    </div>
                                </div>
                                <small v-if="addErrors.number" class="text-danger">{{ addErrors.number }}</small>
                            </div>

                            <!-- Expiration Date -->
                            <div class="row mb-10">
                                <div class="col-md-8 fv-row">
                                    <label class="required fs-6 fw-semibold form-label mb-2">Expiration Date</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <select name="card_expiry_month" class="form-select form-select-solid"
                                                v-model="newCard.expiryMonth"
                                                @change="clearErrorAndValidate('expiry', validateExpiry)" required>
                                                <option disabled value="">Month</option>
                                                <option v-for="month in months" :key="month" :value="month">{{ month }}
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <select name="card_expiry_year" class="form-select form-select-solid"
                                                v-model="newCard.expiryYear"
                                                @change="clearErrorAndValidate('expiry', validateExpiry)" required>
                                                <option disabled value="">Year</option>
                                                <option v-for="year in years" :key="year" :value="year">{{ year }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <small v-if="addErrors.expiry" class="text-danger">{{ addErrors.expiry }}</small>
                                </div>

                                <!-- CVV -->
                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                                        <span class="required">CVV</span>
                                        <span class="ms-1" data-bs-toggle="tooltip" title="Enter a card CVV code">
                                            <i class="fa fa-exclamation text-gray-500"></i>
                                        </span>
                                    </label>
                                    <div class="position-relative">
                                        <input type="text" class="form-control form-control-solid" minlength="3"
                                            maxlength="4" placeholder="CVV" v-model="newCard.cvv"
                                            @input="clearErrorAndValidate('cvv', validateCVV)" required />
                                        <div class="position-absolute translate-middle-y top-50 end-0 me-3">
                                            <i class="fa fa-credit-card fs-2hx"></i>
                                        </div>
                                    </div>
                                    <small v-if="addErrors.cvv" class="text-danger">{{ addErrors.cvv }}</small>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </transition>

    <!--Edit Modal-->
    <transition name="fade">
        <div v-if="isEditCardModalOpen" class="modal-overlay">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>Edit Card</h2>
                        <div class="btn btn-sm btn-icon btn-active-color-primary" @click="toggleEditCardModal">
                            <i class="fa fa-xmark fs-1"></i>
                        </div>
                    </div>
                    <div class="modal-body mx-5 mx-xl-15 my-7">
                        <form @submit.prevent="validateAndSubmitEditCard" novalidate>
                            <!-- Name On Card -->
                            <div class="d-flex flex-column mb-7 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold form-label mb-2">
                                    <span class="required">Name On Card</span>
                                </label>
                                <input type="text" class="form-control form-control-solid" v-model="editCard.name"
                                    @input="clearErrorAndValidate('name', validateEditName)" required />
                                <small v-if="editErrors.name" class="text-danger">{{ editErrors.name }}</small>
                            </div>

                            <!-- Card Number -->
                            <div class="d-flex flex-column mb-7 fv-row">
                                <label class="required fs-6 fw-semibold form-label mb-2">Card Number</label>
                                <input type="text" class="form-control form-control-solid" v-model="editCard.number"
                                    @input="clearErrorAndValidate('number', validateEditCardNumber)" maxlength="19"
                                    required />
                                <small v-if="editErrors.number" class="text-danger">{{ editErrors.number }}</small>
                            </div>

                            <!-- Expiration Date -->
                            <div class="row mb-10">
                                <div class="col-md-8 fv-row">
                                    <label class="required fs-6 fw-semibold form-label mb-2">Expiration Date</label>
                                    <div class="row">
                                        <div class="col-6">
                                            <select name="card_expiry_month" class="form-select form-select-solid"
                                                v-model="editCard.expiryMonth"
                                                @change="clearErrorAndValidate('expiry', validateEditExpiry)" required>
                                                <option disabled value="">Month</option>
                                                <option v-for="month in months" :key="month" :value="month">{{ month }}
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <select name="card_expiry_year" class="form-select form-select-solid"
                                                v-model="editCard.expiryYear"
                                                @change="clearErrorAndValidate('expiry', validateEditExpiry)" required>
                                                <option disabled value="">Year</option>
                                                <option v-for="year in years" :key="year" :value="year">{{ year }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <small v-if="editErrors.expiry" class="text-danger">{{ editErrors.expiry }}</small>
                                </div>

                                <!-- CVV -->
                                <div class="col-md-4 fv-row">
                                    <label class="required">CVV</label>
                                    <div class="position-relative">
                                        <input type="text" class="form-control form-control-solid"
                                            v-model="editCard.cvv"
                                            @input="clearErrorAndValidate('cvv', validateEditCVV)" maxlength="4"
                                            required />
                                        <div class="position-absolute translate-middle-y top-50 end-0 me-3">
                                            <i class="fa fa-credit-card fs-2hx"></i>
                                        </div>
                                    </div>
                                    <small v-if="editErrors.cvv" class="text-danger">{{ editErrors.cvv }}</small>
                                </div>
                            </div>

                            <!-- Submit Button -->
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </transition>


    <!--Delete-->
    <!-- Delete Confirmation Modal -->
    <div v-if="showDeleteModal" class="modal-overlay">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5>Enter Password to Delete Card</h5>
                    <button class="btn btn-icon" @click="showDeleteModal = false">
                        <i class="fa fa-xmark"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="password" v-model="deletePassword" class="form-control"
                        placeholder="Your account password" />
                    <small v-if="deleteError" class="text-danger">{{ deleteError }}</small>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" @click="showDeleteModal = false">Cancel</button>
                    <button class="btn btn-danger" @click="deleteCard">Delete</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
document.querySelectorAll('[data-kt-billing-action="card-delete"]').forEach((button) => {
    button.addEventListener('click', async () => {
        try {
            // Show SweetAlert prompt for password input
            const { value: password } = await Swal.fire({
                title: 'Enter Password to Delete',
                input: 'password',
                inputPlaceholder: 'Your account password',
                inputAttributes: {
                    maxlength: 20,
                    autocapitalize: 'off',
                    autocorrect: 'off',
                },
                showCancelButton: true,
                confirmButtonText: 'Delete',
                cancelButtonText: 'Cancel',
                preConfirm: (password) => {
                    if (!password) {
                        Swal.showValidationMessage('Password is required!');
                    }
                    return password;
                },
            });

            if (password) {
                // Retrieve card ID from the DOM
                const cardId = button.closest('[data-kt-billing-element="card"]').dataset.cardId;

                // Make API call to validate password and delete card
                const response = await axios.post(`/api/cards/${cardId}/delete`, { password });

                // Handle success
                if (response.status === 200) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: response.data.message || 'Card deleted successfully.',
                        timer: 3000,
                        showConfirmButton: false,
                    });

                    // Optionally, remove the card from the DOM
                    button.closest('[data-kt-billing-element="card"]').remove();
                }
            }
        } catch (error) {
            // Handle errors
            if (error.response && error.response.data) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: error.response.data.message || 'An error occurred. Please try again.',
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An unexpected error occurred. Please try again later.',
                });
            }
        }
    });
});

import jQuery from 'jquery'
window.$ = window.jQuery = jQuery
import 'jquery-confirm'

import {
    useToast
} from "vue-toastification";
export default {
    data() {
        return {
            isAddCardModalOpen: false,
            newCard: {
                name: "",
                number: "",
                expiryMonth: "",
                expiryYear: "",
                cvv: "",
            },
            addErrors: {}, // Errors specific to Add Card Modal

            isEditCardModalOpen: false,
            editCard: {
                name: "",
                number: "",
                expiryMonth: "",
                expiryYear: "",
                cvv: "",
            },
            editErrors: {}, // Errors specific to Edit Card Modal
            months: Array.from({
                length: 12
            }, (_, i) => i + 1),
            years: Array.from({
                length: 10
            }, (_, i) => new Date().getFullYear() + i),
            errors: {},
            showDeleteModal: false,
            deleteCardId: null,
            deletePassword: "",
            deleteError: null,
            cards: [],
            loading: true,
        };
    },
    mounted() {
        // console.log('jQuery:', window.jQuery);
        // console.log('jQuery confirm:', typeof window.jQuery.confirm);
        // console.log('jQuery Confirm loaded:', typeof window.jQuery.confirm === 'function');
    },
    async created() {
        try {
            const response = await axios.get('/api/cards'); // Fetch card data from Laravel API
            this.cards = Object.values(response.data); // Convert object to array
            // this.cards = response.data;
        } catch (error) {
            console.error('Error fetching cards:', error);
        } finally {
            this.loading = false;
        }
    },
    methods: {
        async confirmDeleteCard(cardId) {

            if (typeof window.jQuery.confirm !== 'function') {
                console.error('jQuery Confirm is not properly loaded');
                return;
            }

            window.$.confirm({
                type: 'red',
                theme: 'material', // 'material', 'bootstrap', 'supervan'
                title: 'Are you sure?',
                animation: 'scaleX',
                backgroundDismiss: false,
                boxWidth: '50%', // Optional: Adjust the width
                backgroundDismissAnimation: 'glow',
                animationSpeed: 1000, // 2 seconds
                autoClose: 'cancel|8000',
                content: 'This action cannot be undone.',
                buttons: {
                    confirm: {
                        text: 'Yes, delete it',
                        action: async () => {
                            try {
                                // Call your delete API
                                const response = await axios.post(`/api/cards/${cardId}/delete`, {
                                    password: this.deletePassword, // Example
                                });

                                if (response.status === 200) {
                                    this.cards = this.cards.filter((card) => card.id !== cardId);
                                    useToast().success(response.data.message || 'Card deleted successfully.');
                                }
                            } catch (error) {
                                useToast().error(
                                    error.response?.data?.message || 'An unexpected error occurred.'
                                );
                            }
                        },
                    },
                    cancel: {
                        text: 'Cancel',
                        // action: () => {
                        //     useToast().info('Delete operation canceled.');
                        // },
                    },
                },
            });
        },
        confirmDeleteCard2(cardId) {
            this.deleteCardId = cardId;
            this.showDeleteModal = true;
            this.deletePassword = "";
            this.deleteError = null;
        },
        editCardModal(cardId) {
            $.confirm({
                title: 'Edit Card',
                columnClass: 'm',
                content: `url:/api/cards/edit-form/${cardId}`, // Load Laravel Blade form dynamically
                buttons: {
                    save: {
                        text: 'Save Changes',
                        btnClass: 'btn btn-primary',
                        action: function () {
                            // Extract form data
                            const formData = new FormData(this.$content.find('#editCardForm')[0]);

                            // Validate and send data to the backend
                            return new Promise((resolve, reject) => {
                                axios.post(`/api/cards/update/${cardId}`, formData)
                                    .then((response) => {
                                        if (response.data.success) {
                                            // Update the card locally in the Vue data
                                            const updatedCard = response.data.data;
                                            const cardIndex = this.cards.findIndex((card) => card.id === cardId);
                                            if (cardIndex !== -1) {
                                                this.cards[cardIndex] = updatedCard;
                                            }

                                            $.alert({
                                                title: 'Success!',
                                                content: response.data.message,
                                            });
                                            resolve();
                                        } else {
                                            // Handle validation errors
                                            this.$content.find('.form-group').each((index, group) => {
                                                const field = $(group).find('input').attr('name');
                                                if (response.data.errors[field]) {
                                                    $(group).append(
                                                        `<small class="text-danger">${response.data.errors[field][0]}</small>`
                                                    );
                                                }
                                            });
                                            reject();
                                        }
                                    })
                                    .catch((error) => {
                                        if (error.response.status === 404) {
                                            $.alert({
                                                type: 'red',
                                                theme: 'material', // 'material', 'bootstrap', 'supervan'
                                                title: 'Error!',
                                                content: 'Card not found.',
                                            });
                                        } else {
                                            $.alert({
                                                type: 'red',
                                                theme: 'material', // 'material', 'bootstrap', 'supervan'
                                                title: 'Error!',
                                                content: 'An unexpected error occurred.',
                                            });
                                        }
                                        reject();
                                    });
                            });
                        },
                    },
                    cancel: {
                        text: 'Cancel',
                        action: function () {
                            console.log('Edit canceled.');
                        },
                    },
                },
            });
        },
        async deleteCard() {
            if (!this.deletePassword) {
                this.deleteError = "Password is required!";
                return;
            }

            try {
                const response = await axios.post(`/api/cards/${this.deleteCardId}/delete`, {
                    password: this.deletePassword,
                });

                // Ensure the response is successful and data contains the expected structure
                if (response.status === 200 && response.data && response.data.message) {
                    console.log(response, this.cards);

                    // Ensure `this.cards` is an array before applying `.filter`
                    if (Array.isArray(this.cards)) {
                        this.cards = this.cards.filter((card) => card.id !== this.deleteCardId);
                    } else {
                        console.error("`this.cards` is not an array:", this.cards);
                    }

                    this.showDeleteModal = false;
                    // Display success toast
                    useToast().success(response.data.message || "Card deleted successfully.");
                } else {
                    // If the response does not have the expected structure, throw an error
                    throw new Error("Unexpected response structure.");
                }
            } catch (error) {
                console.error("Error occurred:", error);

                // Handle error response from API
                if (error.response && error.response.data) {
                    this.deleteError = error.response.data.message || "An error occurred.";
                } else {
                    this.deleteError = "An unexpected error occurred. Please try again.";
                }

                // Optionally show an error toast
                useToast().error(this.deleteError);
            }

        },
        toggleAddCardModal() {
            this.isAddCardModalOpen = !this.isAddCardModalOpen;
            if (!this.isAddCardModalOpen) {
                // Reset newCard and errors when closing
                this.newCard = {
                    name: "",
                    number: "",
                    expiryMonth: "",
                    expiryYear: "",
                    cvv: "",
                };
                this.addErrors = {};
            }
        },
        validateName() {
            if (!this.newCard.name.trim()) {
                this.addErrors.name = "Card holder name is required.";
            }
        },
        validateCardNumber() {
            this.newCard.number = this.newCard.number
                .replace(/\D/g, "") // Remove non-digits
                .replace(/(\d{4})(?=\d)/g, "$1 "); // Add space every 4 digits

            if (!/^\d{4} \d{4} \d{4} \d{4}$/.test(this.newCard.number)) {
                this.addErrors.number = "Invalid card number format.";
            }
        },
        validateExpiry() {
            if (!this.newCard.expiryMonth || !this.newCard.expiryYear) {
                this.addErrors.expiry = "Expiration date is required.";
            }
        },
        validateCVV() {
            this.newCard.cvv = this.newCard.cvv.replace(/\D/g, ""); // Allow only digits
            if (this.newCard.cvv.length < 3 || this.newCard.cvv.length > 4) {
                this.addErrors.cvv = "Invalid CVV.";
            }
        },
        validateAndSubmitAddCard() {
            this.addErrors = {}; // Reset all errors

            // Run all validations
            this.validateName();
            this.validateCardNumber();
            this.validateExpiry();
            this.validateCVV();

            if (Object.keys(this.addErrors).length > 0) {
                useToast().error("Please correct the errors.", { timeout: 3000 });
                return;
            }

            // Submit the form if there are no errors
            console.log("Card submitted successfully:", this.newCard);
            this.toggleAddCardModal();
        },
        toggleEditCardModal(cardId) {
            this.isEditCardModalOpen = !this.isEditCardModalOpen;
            if (!this.isEditCardModalOpen) {
                // Reset editCard and errors when closing
                this.editCard = {
                    name: "",
                    number: "",
                    expiryMonth: "",
                    expiryYear: "",
                    cvv: "",
                };
                this.editErrors = {};
            } else if (cardId) {
                this.fetchCardDetails(cardId);
            }
        },
        async fetchCardDetails(cardId) {
            try {
                const response = await axios.get(`/api/cards/${cardId}`);
                console.log(response);

                this.editCard = response.data;
            } catch (error) {
                console.error("Error fetching card details:", error);
            }
        },
        // Clear error for a field and run its validation
        clearErrorAndValidate(field, validateFn) {
            // Clear the error for the specific field
            delete this.editErrors[field];

            // Validate after DOM updates
            this.$nextTick(() => {
                validateFn();
            });
        },

        // Validation for edit modal
        validateEditName() {
            if (!this.editCard.name.trim()) {
                this.editErrors.name = "Name on card is required.";
            }
        },
        validateEditCardNumber() {
            this.editCard.number = this.editCard.number
                .replace(/\D/g, "") // Remove non-digits
                .replace(/(\d{4})(?=\d)/g, "$1 "); // Add space every 4 digits

            if (!/^\d{4} \d{4} \d{4} \d{4}$/.test(this.editCard.number)) {
                this.editErrors.number = "Invalid card number format.";
            }
        },
        validateEditExpiry() {
            if (!this.editCard.expiryMonth || !this.editCard.expiryYear) {
                this.editErrors.expiry = "Expiration date is required.";
            }
        },
        validateEditCVV() {
            this.editCard.cvv = this.editCard.cvv.replace(/\D/g, ""); // Allow only digits
            if (this.editCard.cvv.length < 3 || this.editCard.cvv.length > 4) {
                this.editErrors.cvv = "Invalid CVV.";
            }
        },

        validateAndSubmitEditCard() {
            this.editErrors = {}; // Reset all errors

            // Run all validations
            this.validateEditName();
            this.validateEditCardNumber();
            this.validateEditExpiry();
            this.validateEditCVV();

            if (Object.keys(this.editErrors).length > 0) {
                useToast().error("Please correct the errors.", { timeout: 3000 });
                return;
            }

            // If no errors, submit the form
            console.log("Card updated successfully:", this.editCard);
            this.toggleEditCardModal();
        },
    },
};
</script>

<style>
/* Credit Card Section */
.credit-card-section {
    /* padding: 50px 0; */
    /* background-color: #f9f9f9; */
}

.btn.btn-light {
    background-color: #cfe6dbed !important;
}

.section-title {
    font-size: 24px;
    color: #1d1d1d;
    margin-bottom: 20px;
}

.card-container {
    margin-bottom: 40px;
}

.credit-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
}

.card-info {
    color: #555;
}

.card-info h4 {
    font-size: 18px;
    margin-bottom: 5px;
}

.badge.primary {
    background-color: #0d6efd;
    color: #fff;
    padding: 3px 8px;
    font-size: 12px;
    border-radius: 5px;
    margin-left: 10px;
}

.card-actions .btn {
    margin-left: 10px;
    padding: 5px 15px;
    border: 1px solid #ddd;
    background: #fff;
    color: #333;
    border-radius: 5px;
    font-size: 14px;
}

.card-actions .btn.edit {
    border-color: #0d6efd;
    color: #0d6efd;
}

.card-actions .btn.delete {
    border-color: #d9534f;
    color: #d9534f;
}

.transactions-container {
    margin-top: 40px;
}

.transactions-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border: 1px solid #ddd;
}

.transactions-table th,
.transactions-table td {
    padding: 15px;
    border: 1px solid #ddd;
    text-align: left;
}

.transactions-table th {
    background: #f7f7f7;
    color: #333;
}

.transactions-table td img {
    height: 20px;
    margin-right: 10px;
}

.view-link {
    color: #0d6efd;
    text-decoration: none;
}

/* Add Card Button */
.add-card {
    background-color: #0d6efd;
    color: #fff;
    padding: 10px 15px;
    font-size: 14px;
    font-weight: bold;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2000;
}

.modal-content {
    background: #fff;
    border-radius: 10px;
    /* width: 400px; */
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    position: relative;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.close-btn {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
}

.modal-dialog {
    animation: zoom-in 0.3s ease;
}

@keyframes zoom-in {
    from {
        transform: scale(0.8);
    }

    to {
        transform: scale(1);
    }
}

/* Fade transition effect */
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.3s;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>

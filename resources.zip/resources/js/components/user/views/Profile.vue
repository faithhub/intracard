<template>
    <v-row>
        <!-- Welcome Text and Setup Bill Button -->
        <v-col cols="12">
            <v-row>
                <!-- Calendar Card -->
                <v-col cols="12" md="12">
                    <v-card class="calendar-card pa-4" elevation="10">
                        <v-card-title class="text-h6 font-weight-bold mb-4 lt-sp">Profile</v-card-title>
                    </v-card>
                </v-col>
            </v-row>
            </v-col>
    </v-row>
</template>

<script>
import { useToast } from "vue-toastification";
import axios from "@/utils/axios"; // Assuming your custom Axios instance is exported from axios.js

export default {
    name: "Profile",
    data() {
        return {
            form: {
                name: "",
                email: "",
                password: "",
            },
            loading: false,
        };
    },
    methods: {
        async fetchProfile() {
            try {
                const response = await axios.get("/api/user/profile"); // Replace with your API endpoint
                this.form.name = response.data.name;
                this.form.email = response.data.email;
            } catch (error) {
                console.error("Error fetching profile:", error);
            }
        },
        async updateProfile() {
            const toast = useToast();
            this.loading = true;

            try {
                const response = await axios.put("/api/user/profile", this.form); // Replace with your API endpoint
                toast.success("Profile updated successfully!", { timeout: 3000 });
            } catch (error) {
                toast.error(
                    error.response?.data?.message || "Failed to update profile.",
                    { timeout: 5000 }
                );
            } finally {
                this.loading = false;
            }
        },
    },
    mounted() {
        this.fetchProfile();
    },
};
</script>

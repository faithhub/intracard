<template>
    <v-container>
        <!-- Page Title -->
        <v-row class="mb-6">
            <v-col cols="12">
                <h2 class="text-h4 font-weight-bold">Help & Support</h2>
            </v-col>
        </v-row>

        <!-- Main Content -->
        <v-row>
            <!-- Ticket List Section -->
            <v-col cols="12" md="4">
                <v-card class="pa-4 rounded-3" elevation="2">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="text-h6 font-weight-bold">Tickets</h5>
                        <button class="btn btn-sm btn-primary" @click="showCreateTicketModal = true">Create</button>
                    </div>
                    <v-divider class="my-3" style="border-color: #210035;"></v-divider>

                    <!-- Filters -->
                    <v-select v-model="selectedStatus" :items="['All', 'Pending', 'Resolved', 'Unresolved']"
                        label="Filter by Status" dense outlined style="margin-bottom: 10px;"></v-select>

                    <!-- Search Box -->
                    <v-text-field v-model="searchQuery" label="Search tickets..." clearable dense outlined
                        style="margin-bottom: 10px; margin-left: 0;"></v-text-field>

                    <!-- Ticket List -->
                    <v-divider class="mb-3" style="border-color: #210035;"></v-divider>
                    <v-list>
                        <!-- Ticket Items -->
                        <div v-for="ticket in filteredTickets" :key="ticket.id" @click="selectTicket(ticket.id)"
                            style="cursor: pointer;">
                            <div class="d-flex flex-stack py-3">
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-45px symbol-circle">
                                        <span class="symbol-label bg-light-info text-info fs-6 fw-bolder">
                                            {{ ticket.subject[0]?.toUpperCase() || 'T' }}
                                        </span>
                                    </div>
                                    <div class="ms-4">
                                        <div class="fs-5 fw-bold text-gray-900 text-hover-primary mb-1">
                                            {{ truncate(ticket.subject, 20) }}
                                        </div>
                                        <div class="fw-semibold text-muted">
                                            {{ truncate(ticket.last_message || ticket.description, 30) }}
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex flex-column align-items-end ms-3">
                                    <span class="text-muted fs-7 mb-1">{{ formatRelativeTime(ticket.updated_at)
                                        }}</span>
                                    <span class="badge text-capitalize" style="letter-spacing: 1px;"
                                        :class="getStatusBadge(ticket.status)">{{ ticket.status }}</span>
                                    <span v-if="ticket.unreadMessagesCount > 0"
                                        class="badge badge-sm badge-circle badge-light-warning">
                                        {{ ticket.unreadMessagesCount }}
                                    </span>
                                </div>
                            </div>
                            <v-divider style="border-color: #e1e1e1;"></v-divider>
                        </div>
                    </v-list>
                </v-card>

            </v-col>

            <!-- Chat Section -->
            <v-col cols="12" md="8">
                <v-card class="rounded-3 chat-card" elevation="2">
                    <!-- Header Section -->
                    <div class="chat-header d-flex justify-content-between align-items-center px-4 py-2">
                        <div>
                            <h5 class="text-dark mb-1">{{ selectedTicket?.subject || 'Select a Ticket' }}</h5>
                            <p class="text-muted mb-0">
                                {{ selectedTicket?.description || 'No ticket selected.' }}
                            </p>
                            <small v-if="selectedTicket" class="text-muted">
                                Status: <span class="fw-bold badge text-capitalize"
                                    :class="getStatusBadge(selectedTicket.status)">{{ selectedTicket.status }}</span> |
                                Created: {{ formatRelativeTime(selectedTicket.created_at) }}
                            </small>
                        </div>
                        <v-menu offset-y>
                            <template #activator="{ on, attrs }">
                                <v-btn icon v-bind="attrs" v-on="on">
                                    <i class="fa fa-ellipsis-v text-dark"></i>
                                </v-btn>
                            </template>
                            <v-list>
                                <v-list-item @click="closeTicket">
                                    <v-list-item-title>Close Ticket</v-list-item-title>
                                </v-list-item>
                                <v-list-item @click="archiveTicket">
                                    <v-list-item-title>Archive Ticket</v-list-item-title>
                                </v-list-item>
                            </v-list>
                        </v-menu>

                    </div>

                    <!-- Messages Section -->
                    <div class="chat-messages px-4 py-3">
                        <div v-if="selectedTicket">
                            <template v-for="(group, date) in groupedMessages" :key="date">
                                <!-- Date Divider -->
                                <div class="date-divider">
                                    <span>{{ date }}</span>
                                </div>
                                <!-- Messages -->
                                <div v-for="message in group" :key="message.id" class="d-flex mb-3"
                                    :class="{ 'justify-content-end': message.sender_id === user.id, 'justify-content-start': message.sender_id !== user.id }">
                                    <div class="message-bubble"
                                        :class="{ 'sent': message.sender_id === user.id, 'received': message.sender_id !== user.id }">
                                        <p v-if="message.message" class="mb-0">{{ message.message }}</p>
                                            <small class="text-muted">{{ formatRelativeTime(message.created_at)}}</small>
                                        <div v-if="message.file_url" class="file-message">
                                            <a :href="message.file_url" target="_blank" class="file-link">
                                                <i class="fa fa-file"></i> {{ message.file_name }}
                                            </a>
                                            <small class="text-muted">{{ formatRelativeTime(message.created_at)}}</small>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </div>
                        <div v-else>
                            <p class="text-center text-muted">No ticket selected. Select a ticket to start chatting.</p>
                        </div>
                    </div>


                    <!-- File Preview Section -->
                    <div v-if="file" class="file-preview px-4 py-2">
                        <div class="file-preview-card d-flex align-items-center justify-content-between">
                            <i class="fa fa-file text-primary" style="font-size: 24px;"></i>
                            <div class="file-info mx-2">
                                <span class="file-name fw-bold">{{ file.name }}</span>
                                <small class="file-size text-muted">{{ (file.size / 1024).toFixed(2) }} KB</small>
                            </div>
                            <button class="btn btn-sm btn-danger" @click="removeFile">
                                <i class="fa fa-times"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Input Section -->
                    <div class="chat-input d-flex align-items-center px-4 py-3">
                        <button class="btn btn-light" @click="triggerFileInput">
                            <i class="fa fa-paperclip text-dark"></i>
                        </button>
                        <input type="file" ref="fileInput" class="d-none" @change="handleFileChange" />
                        <textarea v-model="message" class="form-control flex-grow-1 mx-3 chat-textarea" rows="2"
                            placeholder="Type a message..."></textarea>
                        <button class="btn btn-primary" @click="sendMessage">
                            <i class="fa fa-paper-plane text-white"></i>
                        </button>
                    </div>
                </v-card>
            </v-col>

        </v-row>

        <!-- Create Ticket Modal -->
        <v-dialog v-model="showCreateTicketModal" max-width="500px">
            <v-card>
                <v-card-title>
                    <span class="text-h6">Create Ticket</span>
                </v-card-title>
                <v-card-text>
                    <v-text-field v-model="newTicket.subject" label="Subject" required></v-text-field>
                    <v-textarea v-model="newTicket.description" label="Description" required></v-textarea>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn text @click="showCreateTicketModal = false">Cancel</v-btn>
                    <v-btn color="primary" @click="createTicket">Create</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script>
import {
    useToast
} from "vue-toastification";
import axios from "axios";

export default {
    data() {
        return {
            defaultAvatar: "https://via.placeholder.com/40x40.png?text=User", // Default avatar
            tickets: [],
            messages: [], // Initialize as an empty array
            user: {
                id: 1, // Replace with actual user data
            },
            file: null, // Selected file
            selectedTicket: null,
            message: "",
            newTicket: { subject: "", description: "" },
            selectedStatus: "All",
            searchQuery: "",
            showCreateTicketModal: false,
        };
    },
    computed: {
        filteredTickets() {
            return this.tickets.filter((ticket) => {
                const matchesStatus =
                    this.selectedStatus === "All" || ticket.status === this.selectedStatus.toLowerCase();
                const matchesSearch =
                    ticket.subject.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
                    ticket.description.toLowerCase().includes(this.searchQuery.toLowerCase());
                return matchesStatus && matchesSearch;
            });
        },
        groupedMessages() {
        // Group messages by formatted date
        return this.messages.reduce((groups, message) => {
            const date = new Date(message.created_at).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
            });
            if (!groups[date]) groups[date] = [];
            groups[date].push(message);
            return groups;
        }, {});
    },
    },
    methods: {
        // Truncate method for ticket description or messages
        truncate(text, limit) {
            if (!text) return "";
            return text.length > limit ? text.substring(0, limit) + "..." : text;
        },
        // Format relative time
        formatRelativeTime(date) {
            const now = new Date();
            const timeDiff = Math.floor((now - new Date(date)) / 1000);

            if (timeDiff < 60) return `${timeDiff} seconds ago`;
            if (timeDiff < 3600) return `${Math.floor(timeDiff / 60)} minutes ago`;
            if (timeDiff < 86400) return `${Math.floor(timeDiff / 3600)} hours ago`;

            return `${Math.floor(timeDiff / 86400)} days ago`;
        },
        fetchTickets() {
            axios.get("/api/tickets").then((response) => {
                // Map tickets to include placeholders for avatar and last message
                this.tickets = response.data.map((ticket) => ({
                    ...ticket,
                    avatar: ticket.avatar || this.defaultAvatar,
                    last_message: ticket.messages?.slice(-1)[0]?.message || "",
                }));
            });
        },
        selectTicket(ticketId) {
            this.selectedTicket = this.tickets.find((ticket) => ticket.id === ticketId);
            axios.get(`/api/tickets/${ticketId}/messages`).then((response) => {
                this.messages = response.data.map((message) => ({
                    ...message,
                    sender_name: message.sender_name || 'Unknown',
                    message: message.message || '',
                    created_at: message.created_at || '',
                }));
            }).catch((error) => {
                console.error("Error fetching messages:", error);
            });
        },
        createTicket() {
            // Frontend validation
            if (!this.newTicket.subject.trim() || !this.newTicket.description.trim()) {
                useToast().error("Both subject and description are required.");
                return;
            }

            axios
                .post("/api/tickets", this.newTicket)
                .then((response) => {
                    // Add the new ticket to the list
                    this.tickets.unshift(response.data);

                    // Clear the form and close the modal
                    this.newTicket = { subject: "", description: "" };
                    this.showCreateTicketModal = false;

                    // Show success message
                    useToast().success("Ticket created successfully.");
                })
                .catch((error) => {
                    // Handle server validation errors
                    if (error.response && error.response.status === 422) {
                        const errors = error.response.data.errors;
                        if (errors.subject) {
                            useToast().error(`Subject: ${errors.subject[0]}`);
                        }
                        if (errors.description) {
                            useToast().error(`Description: ${errors.description[0]}`);
                        }
                    } else {
                        // Handle other errors
                        useToast().error("An error occurred while creating the ticket.");
                    }
                });
        },
        sendMessage() {
            if (!this.message && !this.file) {
                useToast().error("Please type a message or attach a file.");
                return;
            }

            const formData = new FormData();
            formData.append("ticket_id", this.selectedTicket.id);
            if (this.message) formData.append("message", this.message);
            if (this.file) formData.append("file", this.file);

            axios
                .post("/api/tickets/messages", formData, {
                    headers: {
                        "Content-Type": "multipart/form-data",
                    },
                })
                .then((response) => {
                    this.messages.push(response.data);
                    this.message = "";
                    this.file = null; // Clear file after upload
                    this.$refs.fileInput.value = ""; // Reset file input
                })
                .catch((error) => {
                    console.error("Error sending message:", error);
                    useToast().error("Failed to send the message.");
                });
        },
        handleFileChange(event) {
            const file = event.target.files[0];
            if (file.size > 1024 * 1024 * 10) { // 10 MB limit
                useToast.error("File size exceeds the 10MB limit.");
                return;
            }
            this.file = file;
        },
        triggerFileInput() {
            this.$refs.fileInput.click(); // Open file input dialog
        },
        removeFile() {
            this.file = null; // Clear the file from the application state
            this.$refs.fileInput.value = ""; // Reset the file input element
        },
        closeTicket() {
            if (!this.selectedTicket) return;
            axios.post(`/api/tickets/${this.selectedTicket.id}/close`, { status: 'resolved' })
                .then(() => {
                    useToast().success("Ticket closed successfully.");
                    this.fetchTickets();
                })
                .catch((error) => {
                    console.error("Error closing ticket:", error);
                    useToast().error("Failed to close the ticket.");
                });
        },
        archiveTicket() {
            if (!this.selectedTicket) return;
            useToast().info("Archive ticket functionality is under development.");
        },
        getStatusBadge(status) {
            switch (status) {
                case "pending":
                    return "badge-warning";
                case "resolved":
                    return "badge-success";
                case "unresolved":
                    return "badge-danger";
                default:
                    return "badge-secondary";
            }
        },
    },
    mounted() {
        this.fetchTickets();
    },
};
</script>

<style>
.date-divider {
    text-align: center;
    margin: 10px 0;
    font-size: 14px;
    color: #6c757d;
    font-weight: bold;
    position: relative;
}

.date-divider span {
    background-color: #f8f8f8;
    padding: 0 10px;
    position: relative;
    z-index: 2;
}

.date-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background-color: #e0e0e0;
    z-index: 1;
}


.v-menu {
    z-index: 1000;
    /* Ensures the dropdown is above other elements */
}

.chat-box {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 10px;
}

.chat-message {
    background-color: #f5f5f5;
    max-width: 75%;
    display: inline-block;
}

.text-right .chat-message {
    background-color: #e3f2fd;
}

.symbol {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    width: 45px;
    height: 45px;
}

.symbol-label {
    font-size: 18px;
    font-weight: bold;
    color: #212529 !important;
}

.fs-5 {
    font-size: 16px !important;
}

.fs-7 {
    font-size: 12px !important;
}

.text-gray-900 {
    color: #212529;
}

.text-muted {
    color: #6c757d;
}

.fw-semibold {
    font-size: 12px !important;
}

.badge {
    padding: 0.3em 0.6em;
    border-radius: 0.5em;
    font-size: 12px;
}

.badge-warning {
    background-color: #ffc107;
    color: #fff;
}

.badge-success {
    background-color: #28a745;
    color: #fff;
}

.badge-danger {
    background-color: #dc3545;
    color: #fff;
}

.separator-dashed {
    border-top: 1px dashed #e1e1e1;
    margin-top: 10px;
    margin-bottom: 10px;
}

.v-card {
    padding: 20px;
    border-radius: 8px;
}

.d-flex {
    display: flex;
}

.justify-content-between {
    justify-content: space-between;
}

.align-items-center {
    align-items: center;
}

.symbol {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    width: 45px;
    height: 45px;
}

.symbol-label {
    font-size: 16px;
    font-weight: bold;
}

.v-btn {
    font-size: 12px;
    /* Make the button smaller */
    padding: 6px 12px;
}

.v-divider {
    border-color: #100218 !important;
    /* Apply your custom color */
}

.v-select,
.v-text-field {
    margin-bottom: 10px;
    margin-left: 0;
    /* Remove left margin */
}

.fs-5 {
    font-size: 16px;
}

.fs-7 {
    font-size: 12px;
}

.file-preview {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    margin-bottom: 10px;
}

.file-preview-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
}

.file-info {
    margin-left: 10px;
    flex-grow: 1;
}

.file-name {
    font-weight: bold;
}

.file-size {
    font-size: 12px;
    color: #6c757d;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.5s;
}

.fade-enter,
.fade-leave-to {
    opacity: 0;
}

.chat-message {
    background-color: #f8f9fa;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 8px;
    max-width: 70%;
}

.text-right .chat-message {
    background-color: #d1ecf1;
    color: #0c5460;
}

.file-preview-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    background-color: #f9f9f9;
}

.file-info {
    margin-left: 10px;
}

.btn-primary {
    background-color: #210035;
    border-color: #210035;
}

.btn-secondary {
    background-color: #6c757d;
    border-color: #6c757d;
}

.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.ticket-details-header {
    padding: 10px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    background-color: #f8f9fa;
    margin-bottom: 15px;
}

.chat-box {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 10px;
}

.chat-message {
    background-color: #efecec91;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 8px;
    max-width: 70%;
}

.text-right .chat-message {
    background-color: #e8f4fd;
}

.btn-secondary {
    background-color: #6c757d;
    color: #fff;
    border: none;
}

.btn-primary {
    background-color: #210035;
    color: #fff;
    border: none;
}

.btn-link {
    color: #210035;
    font-size: 14px;
    text-decoration: none;
}

.badge {
    padding: 5px 10px;
    font-size: 12px;
    border-radius: 5px;
    color: #fff;
}

.badge-warning {
    background-color: #ffc107;
}

.badge-success {
    background-color: #28a745;
}

.badge-danger {
    background-color: #dc3545;
}

.chat-container {
    background-color: #f8f8f8;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.chat-card {
    background-color: #ffffff;
    width: 100%;
    max-width: 800px;
    border-radius: 10px;
    border: 1px solid #e0e0e0;
    overflow: hidden;
}

.chat-header {
    background-color: #efecec91;
    /* border-bottom: 1px solid #e0e0e0; */
}

.chat-messages {
    max-height: 400px;
    overflow-y: auto;
}

.message-bubble {
    max-width: 60%;
    padding: 10px 15px;
    border-radius: 15px;
    font-size: 14px;
}

.message-bubble.sent {
    background-color: #d1ecf1;
    color: #0c5460;
}

.message-bubble.received {
    background-color: #f8f9fa;
    color: #212529;
}

.file-preview-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #f8f9fa;
    padding: 10px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
}

.chat-input {
    background-color: #efecec91;
    border-top: 1px solid #e0e0e0;
}

.file-link {
    color: #212529;
    text-decoration: none;
    font-size: 14px;
    display: block;
    /* Ensures the link is on its own line */
    margin-bottom: 5px;
}

.file-link:hover {
    text-decoration: underline;
}


.chat-textarea {
    resize: none;
    border-radius: 10px;
    border: 1px solid #e0e0e0;
}

.file-message {
    margin-top: 5px;
}

.message-bubble small {
    display: block;
    /* Ensures timestamp is on a new line */
    margin-top: 5px;
}
</style>

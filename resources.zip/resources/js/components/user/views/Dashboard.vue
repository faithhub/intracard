<template>
    <v-row>
        <!-- Welcome Text and Setup Bill Button -->
        <v-col cols="12" class="d-flex justify-space-between align-center mb-4">
            <h2 class="text-h4 font-weight-bold">Welcome, Faith!</h2>
            <v-btn color="purple" class="text-white" elevation="2" rounded>
                Setup Bill
            </v-btn>
        </v-col>

        <!-- Main Section -->
        <v-col cols="12">
            <v-row>
                <!-- Calendar Card -->
                <v-col cols="12" md="8">
                    <v-card class="calendar-card pa-4" elevation="10">
                        <h3 class="text-h6 font-weight-bold mb-4">My Payment Calendar</h3>

                        <!-- Legend -->
                        <div class="legend mb-4">
                            <v-chip color="purple" class="ma-1">Payment Duration</v-chip>
                            <v-chip color="amber" class="ma-1">Bills Payment</v-chip>
                            <v-chip color="green" class="ma-1">Last Payments</v-chip>
                            <v-chip color="blue" class="ma-1">Upcoming Payments</v-chip>
                        </div>

                        <!-- FullCalendar -->
                        <FullCalendar :options="calendarOptions" />
                    </v-card>
                </v-col>

                <!-- Cards Beside Calendar -->
                <v-col cols="12" md="4">
                    <!-- Mortgage Amount Card -->
                    <v-card class="calendar-card pa-4 mb-4" elevation="10">
                        <h3 class="text-h6 font-weight-bold mb-3 text-purple">$5,000.00</h3>
                        <p class="text-caption mb-2">Mortgage Amount</p>
                        <v-divider></v-divider>
                        <div class="mt-3">
                            <p><strong>Nature of Transaction:</strong> Mortgage</p>
                            <p><strong>Contract Address:</strong></p>
                            <p class="text-caption text-muted">
                                Address: Canada Energy Regulator (Formerly the National Energy Board), 517 10th Avenue
                                SW, Calgary,
                                Alberta T2P 3V5, Canada
                                <br />
                                Province: Alberta
                                <br />
                                City: Calgary
                                <br />
                                Postal Code: T2P 3V5
                            </p>
                        </div>
                    </v-card>

                    <!-- Credit Score Card -->
                    <v-card class="calendar-card pa-4" elevation="10">
                        <div class="d-flex justify-space-between align-center mb-3">
                            <h3 class="text-h6 font-weight-bold mb-0">Credit Score</h3>
                            <v-switch inset color="purple" v-model="creditAgency" true-value="TransUnion"
                                false-value="Equifax"></v-switch>
                        </div>
                        <div class="text-center">
                            <v-progress-circular :value="creditScore" color="green" width="10" size="120" class="mb-2">
                                {{ creditScore }}
                            </v-progress-circular>
                            <p class="text-caption">Credit Score: {{ creditAgency }}</p>
                        </div>
                    </v-card>
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>

<script>
import FullCalendar from "@fullcalendar/vue3";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";

export default {
    components: {
        FullCalendar,
    },
    data() {
        return {
            // Calendar Options
            calendarOptions: {
                height: 'auto', // or a specific pixel value
                plugins: [dayGridPlugin, interactionPlugin],
                initialView: "dayGridMonth",
                headerToolbar: {
                    start: "prev,next today",
                    center: "title",
                    end: "dayGridYear,dayGridMonth,dayGridWeek,dayGridDay",
                },
                events: [
                    { title: "Mortgage Payment", start: "2024-12-03", color: "purple" },
                    { title: "Bills Payment", start: "2024-12-10", color: "amber" },
                    { title: "Last Payment", start: "2024-12-17", color: "green" },
                    { title: "Upcoming Payment", start: "2024-12-22", color: "blue" },
                ],
            },
            creditScore: 560,
            creditAgency: "Equifax",
        };
    },
};
</script>

<style scoped>
.calendar-card {
    background-color: #fffdfd;
    border-radius: 12px;
}

.legend {
    display: flex;
    flex-wrap: wrap;
}

.text-purple {
    color: #6a1b9a !important;
}

.text-muted {
    color: #6c757d !important;
}

.pa-4 {
    padding: 1rem;
}
</style>
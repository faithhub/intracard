<template>
    <v-row>
        <!-- Welcome Text and Setup Bill Button -->
        <v-col cols="12">
            <v-row>
                <!-- Calendar Card -->
                <v-col cols="12" md="12">
                    <v-card class="calendar-card pa-4" elevation="10">
                        <v-card-title class="text-h6 font-weight-bold mb-4 lt-sp">Mortgage Details</v-card-title>
                    </v-card>
                </v-col>
            </v-row>
            </v-col>
    </v-row>
</template>
<template>
    <v-row>
        <!-- Wallet Balance and Fund Wallet Button -->
        <v-col cols="12" md="12">
            <v-card class="calendar-card pa-4 rounded-3" elevation="10">
                <!-- Wallet Balance Section -->
                <div class="py-5 p-5">
                    <div class="card mb-5">
                        <div class="card-body d-flex justify-content-between align-items-center">
                            <!-- Wallet Balance -->
                            <div>
                                <h3 class="text-gray-800 fw-bold mb-2">Wallet Balance</h3>
                                <h1 class="text-black fw-bold">$ {{ walletBalance }}</h1>
                            </div>

                            <!-- Fund Wallet Button -->
                            <div>
                                <button class="btn btn-primary btn-sm" @click="toggleFundWalletModal">
                                    <i class="fa fa-wallet fs-4"></i> Fund Wallet
                                </button>
                            </div>
                        </div>
                    </div>


                    <!-- Transactions -->
                    <div class="card mb-5 mb-xl-12">
                        <!--begin::Card header-->
                        <div class="card-header card-header-stretch pb-0">
                            <!--begin::Title-->
                            <div class="card-title">
                                <h3 class="m-0">Transactions</h3>
                            </div>
                        </div>

                        <div class="card-body pt-0">
                            <div class="table-responsive">
                                <table class="table align-middle table-row-dashed fs-6 gy-5" id="transactionTable">
                                    <thead>
                                        <tr class="text-start text-gray-500 fw-bold fs-7 text-uppercase" width="3">
                                            <!-- Checkbox Column -->
                                            <th class="w-5 pe-2 dt-orderable-none">
                                                <span class="dt-column-title">
                                                    <div
                                                        class="form-check form-check-sm form-check-custom form-check-solid me-3">
                                                        <input class="form-check-input" type="checkbox"
                                                            data-kt-check="true"
                                                            data-kt-check-target="#transactionTable .form-check-input"
                                                            value="1">
                                                    </div>
                                                </span>
                                            </th>
                                            <th width="17%">Transaction ID</th>
                                            <th width="17%">Date</th>
                                            <th width="15%">Amount</th>
                                            <th width="10%">Bill Type</th>
                                            <th width="18%">Transaction Type</th>
                                            <th width="5%">Status</th>
                                            <th class="text-end" width="10%">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div
                                                    class="form-check form-check-sm form-check-custom form-check-solid">
                                                    <input class="form-check-input" type="checkbox" value="1">
                                                </div>
                                            </td>
                                            <td>#TRX123456</td>
                                            <td>20 Nov 2024</td>
                                            <td>$50.00</td>
                                            <td>Utility Bill</td>
                                            <td>
                                                <span
                                                    class="badge badge-light-success text-black px-2 text-gray-800 fw-bold fs-5">
                                                    Inbound&nbsp;
                                                    <i class="fa fa-arrow-down fs-4 text-success badge-i"></i>
                                                </span>
                                            </td>
                                            <td><span class="badge badge-light-success">Completed</span>
                                            </td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-light-primary" data-bs-toggle="modal"
                                                    data-bs-target="#transactionDetailsModal"
                                                    onclick="showTransactionDetails('#TRX123456', 'Utility Bill', '$50.00', '20 Nov 2024', 'Completed')">
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div
                                                    class="form-check form-check-sm form-check-custom form-check-solid">
                                                    <input class="form-check-input" type="checkbox" value="1">
                                                </div>
                                            </td>
                                            <td>#TRX123457</td>
                                            <td>18 Nov 2024</td>
                                            <td>$100.00</td>
                                            <td>Car Bill</td>
                                            <td>
                                                <span
                                                    class="badge badge-light-warning text-black px-2 text-gray-800 fw-bold fs-5">
                                                    Outbound&nbsp;
                                                    <i class="fa fa-arrow-up fs-4 text-warning badge-i"></i>
                                                </span>
                                            </td>
                                            <td><span class="badge badge-light-warning">Pending</span></td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-light-primary" data-bs-toggle="modal"
                                                    data-bs-target="#transactionDetailsModal"
                                                    onclick="showTransactionDetails('#TRX123457', 'Car Bill', '$100.00', '18 Nov 2024', 'Pending')">
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </v-card>
        </v-col>

        <!-- Fund Wallet Modal -->
        <transition name="fade">
            <div v-if="isFundWalletModalOpen" class="modal-overlay">
                <div class="modal-dialog modal-dialog-centered custom-modal-width">
                    <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h2>Fund Wallet</h2>
                            <button class="btn btn-sm btn-icon btn-active-color-primary" @click="toggleFundWalletModal">
                                <i class="fa fa-xmark fs-1"></i>
                            </button>
                        </div>

                        <!-- Modal Body -->
                        <div class="modal-body mx-5 mx-xl-15 my-7">
                            <form @submit.prevent="validateAndSubmitFundWallet" id="walletForm" novalidate>
                                <!-- Amount Input -->
                                <div class="mb-5">
                                    <label for="amount" class="form-label fw-bold">Enter Amount</label>
                                    <input type="number" class="form-control form-control-lg"
                                        v-model="fundWallet.amount" placeholder="Enter amount" min="1"
                                        @input="clearError('amount')" />
                                    <small v-if="fundWalletErrors.amount" class="text-danger">{{ fundWalletErrors.amount
                                        }}</small>
                                </div>

                                <!-- Services Dropdown -->
                                <div class="mb-5">
                                    <label for="service" class="form-label fw-bold">Select Service</label>
                                    <select class="form-select form-select-solid" v-model="fundWallet.service"
                                        @change="clearError('service')">
                                        <option value="">Select Service</option>
                                        <option value="Rent">Rent</option>
                                        <option value="carBill">Car Bill</option>
                                        <option value="utilityBill">Utility Bill</option>
                                        <option value="phoneBill">Phone Bill</option>
                                        <option value="internetBill">Internet Bill</option>
                                    </select>
                                    <small v-if="fundWalletErrors.service" class="text-danger">{{
                                        fundWalletErrors.service }}</small>
                                </div>

                                <!-- Payment Card Selection -->
                                <div v-if="isLoading">Loading cards...</div>
                                <div v-else>
                                    <div class="mb-0">
                                        <!-- Loop through cards dynamically -->
                                        <label v-for="card in cards" :key="card.id"
                                            class="d-flex flex-stack mb-5 cursor-pointer">
                                            <span class="d-flex align-items-center me-2">
                                                <!-- Card Logo -->
                                                <span class="symbol symbol-50px me-6">
                                                    <span class="symbol-label">
                                                        <img :src="card.logoUrl" :alt="card.type" class="h-40px" />
                                                    </span>
                                                </span>
                                                <!-- Card Details -->
                                                <span class="d-flex flex-column">
                                                    <span class="fw-bold text-gray-800 text-hover-primary fs-5">
                                                        {{ card.type }} **** {{ card.lastFourDigits }}
                                                    </span>
                                                    <span class="fs-6 fw-semibold text-muted">
                                                        Expires {{ card.expiryMonth }}/{{ card.expiryYear }}
                                                    </span>
                                                    <span class="fs-6 fw-semibold text-muted">
                                                        Card Limit:
                                                        <span class="fw-bold text-gray-800">
                                                            ${{ card.limit.toLocaleString() }}
                                                        </span>
                                                    </span>
                                                </span>
                                            </span>
                                            <!-- Radio Button -->
                                            <span class="form-check form-check-custom form-check-solid">
                                                <input class="form-check-input" type="radio" name="payment_card"
                                                    :value="card.id" v-model="fundWallet.card"
                                                    @change="clearError('card')" />
                                            </span>
                                        </label>
                                        <!-- Error Display -->
                                        <small v-if="fundWalletErrors.card" class="text-danger">{{ fundWalletErrors.card
                                            }}</small>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">Fund Wallet</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </transition>
    </v-row>
</template>

<script>
import {
    useToast
} from "vue-toastification";
import axios from "axios";

export default {
    data() {
        return {
            walletBalance: 1250.50, // Example wallet balance
            isFundWalletModalOpen: false, // Modal state
            fundWallet: {
                amount: null,
                service: "",
                card: null,
            },
            isLoading: false,
            fundWalletErrors: {}, // Validation errors
            cards: [],
        };
    },
    methods: {
        // Fetch cards from the API
        async fetchCards() {
            this.isLoading = true;
            try {
                const response = await axios.get("/api/cards");

                // Process the response data
                if (response.data && typeof response.data === "object") {
                    // Convert the numbered object keys into an array
                    const rawCards = Object.values(response.data);
                    console.log(rawCards);

                    this.cards = rawCards.map((card) => ({
                        id: card.id,
                        type: card.type || "Unknown", // Default to "Unknown" if type is missing
                        limit: card.limit || 0, // Default to "Unknown" if type is missing
                        lastFourDigits: card.number.slice(-4), // Extract the last 4 digits of the card number
                        expiryMonth: card.expiryMonth,
                        expiryYear: card.expiryYear,
                        isPrimary: card.is_primary || false, // Check if the card is primary
                        logoUrl: card.logoUrl || this.getCardLogo(card.type), // Use default logo if not provided
                    }));
                } else {
                    console.error("Unexpected response format:", response);
                    this.cards = []; // Fallback to an empty array
                }
            } catch (error) {
                console.error("Failed to fetch cards:", error);
                this.cards = []; // Reset cards on error
            } finally {
                this.isLoading = false;
            }
        }
        ,
        // Helper function to get card logo URL if not provided
        getCardLogo(type) {
            if (!type || typeof type !== "string") {
                // Return a default card logo if type is missing or invalid
                return "https://example.com/default-card.png";
            }

            switch (type.toLowerCase()) {
                case "visa":
                    return "https://example.com/visa.png";
                case "mastercard":
                    return "https://example.com/mastercard.png";
                default:
                    return "https://example.com/default-card.png";
            }
        },
        // Toggle the Fund Wallet Modal
        toggleFundWalletModal() {
            this.isFundWalletModalOpen = !this.isFundWalletModalOpen;
            if (!this.isFundWalletModalOpen) {
                this.resetFundWalletForm();
            }
        },

        // Reset the Fund Wallet Form
        resetFundWalletForm() {
            this.fundWallet = {
                amount: null,
                service: "",
                card: null,
            };
            this.fundWalletErrors = {};
        },

        // Clear Specific Error
        clearError(field) {
            if (this.fundWalletErrors[field]) {
                delete this.fundWalletErrors[field];
            }
        },

        // Validate and Submit the Fund Wallet Form
        async validateAndSubmitFundWallet() {
            this.fundWalletErrors = {}; // Clear previous errors

            // Validate Inputs
            if (!this.fundWallet.amount || this.fundWallet.amount <= 0) {
                this.fundWalletErrors.amount = "Please enter a valid amount.";
            }
            if (!this.fundWallet.service) {
                this.fundWalletErrors.service = "Please select a service.";
            }
            if (!this.fundWallet.card) {
                this.fundWalletErrors.card = "Please select a payment card.";
            }

            // Stop submission if there are errors
            if (Object.keys(this.fundWalletErrors).length > 0) {
                return;
            }

            // Submit Form Data to Backend
            try {
                const response = await axios.post("/api/wallet/fund", this.fundWallet);
                if (response.data.success) {
                    this.walletBalance = response.data.newBalance; // Update wallet balance
                    this.toggleFundWalletModal(); // Close modal
                    useToast().success(response.data.message || "Wallet funded successfully.");
                }
            } catch (error) {
                if (error.response && error.response.data.errors) {
                    this.fundWalletErrors = error.response.data.errors; // Display validation errors
                } else {
                    useToast().error("An unexpected error occurred. Please try again.");
                }
            }
        },
    },
    // Fetch cards when the component is mounted
    mounted() {
        this.fetchCards();
    },
};
</script>

<style>
.custom-modal-width {
    margin-left: 1rem;
    margin-right: 1rem;
    max-width: 600px;
    /* Adjust the width as needed */
    width: 100%;
}

/* Modal Styles */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2000;
}

.modal-content {
    background: #fff;
    border-radius: 10px;
    /* min-width: 400px; */
    padding: 20px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    position: relative;
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.close-btn {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
}

.modal-dialog {
    animation: zoom-in 0.3s ease;
}

@keyframes zoom-in {
    from {
        transform: scale(0.8);
    }

    to {
        transform: scale(1);
    }
}
</style>
<template>
    <div id="kt_app_sidebar" class="app-sidebar flex-column">
      <div class="app-sidebar-logo d-none d-lg-flex flex-stack flex-shrink-0 px-8">
        <a href="/">
          <img alt="Logo" src="@assets/logos/intracard_new.png" class="theme-light-show h-70px" />
        </a>
      </div>
      <div class="separator d-none d-lg-block"></div>
      <div class="app-sidebar-menu hover-scroll-y my-5 mx-3" id="kt_app_sidebar_menu_wrapper">
        <div class="menu menu-column menu-sub-indention menu-active-bg fw-semibold">
          <div class="menu-item">
            <a class="menu-link" href="/dashboard">
              <span class="menu-icon"><i class="fa fa-house"></i></span>
              <span class="menu-title">Dashboard</span>
            </a>
            <a class="menu-link" href="/rental-details">
              <span class="menu-icon"><i class="fa fa-house"></i></span>
              <span class="menu-title">Rental Details</span>
            </a>
            <a class="menu-link" href="/billing-details">
              <span class="menu-icon"><i class="fa fa-credit-card"></i></span>
              <span class="menu-title">My Cards</span>
            </a>
            <a class="menu-link" href="/wallet">
              <span class="menu-icon"><i class="fa fa-wallet"></i></span>
              <span class="menu-title">Wallet</span>
            </a>
            <a class="menu-link" href="/chat-us">
              <span class="menu-icon"><i class="fa fa-comments"></i></span>
              <span class="menu-title">Chat Support</span>
            </a>
          </div>
        </div>
      </div>
      <div class="app-sidebar-user d-flex flex-stack py-5 px-8">
        <a class="menu-link" href="#" @click="logout">
          <span class="menu-icon"><i class="fa fa-right-from-bracket" style="color: red"></i></span>
          <span class="menu-title" style="color: red">Logout</span>
        </a>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    methods: {
      logout() {
        // Handle logout logic here
        console.log("User logged out");
      },
    },
  };
  </script>
  
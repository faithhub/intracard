<template>
    <div id="kt_app_footer" class="app-footer">
      <div class="app-container container-fluid d-flex flex-column flex-md-row flex-center py-3">
        <div class="text-gray-900">
          <span>2024 &copy; </span>
          <a href="/" class="text-hover-primary">Intracard</a>
        </div>
        <ul class="menu menu-gray-600 menu-hover-primary">
          <li><a href="#">About</a></li>
          <li><a href="#">Support</a></li>
          <li><a href="#">Terms</a></li>
        </ul>
      </div>
    </div>
  </template>  

<script>
export default {
    name: "Footer",
};
</script>

<style scoped>
.footer {
    background-color: #f8f9fa;
    padding: 15px 20px;
    text-align: center;
    color: #6c757d;
}
</style>

<template>
    <!-- <header class="header"> -->
        <div id="kt_app_header" class="app-header">
    <!--begin::Header container-->
    <div class="app-container  container-fluid d-flex align-items-stretch justify-content-between "
        id="kt_app_header_container">
        <!--begin::Mobile menu toggle-->
        <div class="d-flex align-items-center d-lg-none ms-n2 me-2" title="Show sidebar menu">
            <div class="btn btn-icon btn-active-color-primary w-35px h-35px" id="kt_app_sidebar_mobile_toggle">
                <i class="fa fa-bars fs-1" style="font-size: 2.5rem !important;"></i>
                <i class="fa fa-user fs-1"></i> 
            </div>
        </div>
        <!--end::Mobile menu toggle-->
        <!--begin::Mobile logo-->
        <div class="d-flex align-items-center flex-grow-1 flex-lg-grow-0">
            <a href="" class="d-lg-none">
                <img alt="Logo" src="@assets/logos/intracard.png" class="h-45px" />
            </a>
        </div>
        <!--end::Mobile logo-->
        <!--begin::Header wrapper-->
        <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1" id="kt_app_header_wrapper">
            <!--begin::Page title-->
            <div data-kt-swapper="true" data-kt-swapper-mode="{default: 'prepend', lg: 'prepend'}"
                data-kt-swapper-parent="{default: '#kt_app_content_container', lg: '#kt_app_header_wrapper'}"
                class="page-title d-flex flex-column justify-content-center flex-wrap me-3 mb-5 mb-lg-0">
                <!--begin::Title-->
                <h1 class="page-heading d-flex text-gray-900 fw-bold fs-3 flex-column justify-content-center my-0">
                    Dashboard
                </h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-muted">
                        <a href="" class="breadcrumb-link text-muted text-hover-primary">
                            Home
                        </a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-300 w-5px h-2px"></span>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-muted" id="topNavText">
                        My Account
                    </li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>

            <div class="app-navbar align-items-center flex-shrink-0">
                <div class="app-sidebar-user d-flex flex-stack">
                    <div class="d-flex">
                        <div class="app-navbar-item ms-2 ms-lg-4" style="margin-right: 1rem;">
                            <a href="#" class="btn btn-icon btn-secondary mr-2 fw-bold position-relative"
                                data-kt-menu-trigger="click" data-kt-menu-attach="parent"
                                data-kt-menu-placement="bottom-end" data-kt-menu-flip="bottom"
                                style="height: calc(1.3em + 1.3rem + 2px); width: calc(1.3em + 1.25rem + 2px);">
                                <i class="fa fa-bell fs-2"></i>
                                <span class="notification-badge position-absolute top-0 start-100 translate-middle"
                                    style="display: none;">0</span>
                            </a>
                            <div class="menu menu-sub menu-sub-dropdown menu-column w-300px w-lg-375px"
                                data-kt-menu="true" id="kt_menu_notifications" style="">

                                <div class="d-flex flex-column bgi-no-repeat rounded-top"
                                    style="background-image:url('')">

                                    <h3 class="text-black fw-semibold px-9 mt-10 mb-6">
                                        Notifications <span class="fs-8 opacity-75 ps-3">0 reports</span>
                                    </h3>

                                    <ul class="nav nav-line-tabs nav-line-tabs-2x nav-stretch fw-semibold px-9"
                                        role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link text-black opacity-75 opacity-state-100 pb-4 active"
                                                data-bs-toggle="tab" href="#kt_topbar_notifications_1"
                                                aria-selected="false" tabindex="-1" role="tab">
                                                General (0)
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link text-black opacity-75 opacity-state-100 pb-4"
                                                data-bs-toggle="tab" href="#kt_topbar_notifications_2"
                                                aria-selected="true" role="tab">
                                                Payment (0)
                                            </a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link text-black opacity-75 opacity-state-100 pb-4"
                                                data-bs-toggle="tab" href="#kt_topbar_notifications_3"
                                                aria-selected="false" tabindex="-1" role="tab">
                                                Reminder (0)
                                            </a>
                                        </li>
                                    </ul>

                                </div>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="kt_topbar_notifications_1"
                                        role="tabpanel">
                                        <div class="scroll-y mh-325px my-5 px-8">
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-primary">
                                                            <i class="ki-duotone ki-abstract-28 fs-2 text-primary"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">Project
                                                            Alice</a>
                                                        <div class="text-gray-500 fs-7">Phase 1 development</div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">1 hr</span>
                                            </div>
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-danger">
                                                            <i class="ki-duotone ki-information fs-2 text-danger"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span><span
                                                                    class="path3"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">HR
                                                            Confidential</a>
                                                        <div class="text-gray-500 fs-7">Confidential staff documents
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">2 hrs</span>
                                            </div>
                                        </div>
                                        <div class="py-3 text-center border-top">
                                            <div class="pagination-container"></div>
                                            <a href="" class="btn btn-color-black-600 btn-active-color-dark">
                                                View All
                                                <i class="fc-icon fc-icon-chevron-right fs-5"><span
                                                        class="path1"></span><span class="path2"></span></i>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="kt_topbar_notifications_2" role="tabpanel">
                                        <div class="scroll-y mh-325px my-5 px-8">
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-primary">
                                                            <i class="ki-duotone ki-abstract-28 fs-2 text-primary"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">Project
                                                            Alice</a>
                                                        <div class="text-gray-500 fs-7">Phase 1 development</div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">1 hr</span>
                                            </div>
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-danger">
                                                            <i class="ki-duotone ki-information fs-2 text-danger"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span><span
                                                                    class="path3"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">HR
                                                            Confidential</a>
                                                        <div class="text-gray-500 fs-7">Confidential staff documents
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">2 hrs</span>
                                            </div>
                                        </div>
                                        <div class="py-3 text-center border-top">
                                            <a href="" class="btn btn-color-black-600 btn-active-color-dark">
                                                View All
                                                <i class="fc-icon fc-icon-chevron-right fs-5"><span
                                                        class="path1"></span><span class="path2"></span></i>
                                            </a>
                                        </div>
                                    </div>


                                    <div class="tab-pane fade" id="kt_topbar_notifications_3" role="tabpanel">
                                        <div class="scroll-y mh-325px my-5 px-8">
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-primary">
                                                            <i class="ki-duotone ki-abstract-28 fs-2 text-primary"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">Project
                                                            Alice</a>
                                                        <div class="text-gray-500 fs-7">Phase 1 development</div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">1 hr</span>
                                            </div>
                                            <div class="d-flex flex-stack py-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="symbol symbol-35px me-4">
                                                        <span class="symbol-label bg-light-danger">
                                                            <i class="ki-duotone ki-information fs-2 text-danger"><span
                                                                    class="path1"></span><span
                                                                    class="path2"></span><span
                                                                    class="path3"></span></i>
                                                        </span>
                                                    </div>
                                                    <div class="mb-0 me-2">
                                                        <a href="#"
                                                            class="fs-6 text-gray-800 text-hover-primary fw-bold">HR
                                                            Confidential</a>
                                                        <div class="text-gray-500 fs-7">Confidential staff documents
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-light fs-8">2 hrs</span>
                                            </div>
                                        </div>
                                        <div class="py-3 text-center border-top">
                                            <a href="" class="btn btn-color-black-600 btn-active-color-dark">
                                                View All
                                                <i class="fc-icon fc-icon-chevron-right fs-5"><span
                                                        class="path1"></span><span class="path2"></span></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="me-5 remove-pp-margin">
                            <div class="symbol symbol-40px cursor-pointer"
                                data-kt-menu-trigger="{default: 'click', lg: 'hover'}"
                                data-kt-menu-placement="bottom-start" data-kt-menu-overflow="true">
                                <img src="https://img.freepik.com/premium-vector/avatar-icon0002_750950-43.jpg?semt=ais_hybrid"
                                    alt="" />
                            </div>
                            <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-color fw-semibold py-4 fs-6 w-275px"
                                data-kt-menu="true">
                                <div class="menu-item px-3">
                                    <div class="menu-content d-flex align-items-center px-3">
                                        <div class="symbol symbol-50px me-5">
                                            <img alt="Logo"
                                                src="https://img.freepik.com/premium-vector/avatar-icon0002_750950-43.jpg?semt=ais_hybrid" />
                                        </div>
                                        <div class="d-flex flex-column">
                                            <div class="fw-bold d-flex align-items-center fs-5">
                                                {{ firstName ?? '--' }}
                                                {{ lastName ?? '--' }}
                                                <span class="badge badge-light-success fw-bold fs-8 px-2 py-1 ms-2">
                                                    Pro
                                                </span>
                                            </div>
                                            <a href="#"
                                                class="fw-semibold text-muted text-hover-primary fs-7">{{ email ?? '--' }}
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="separator my-2"></div>
                                <div class="menu-item px-5">
                                    <a href="{{ route('profile') }}" class="menu-link px-5">
                                        My Profile
                                    </a>
                                </div>
                                <div class="menu-item px-5">
                                    <a href="{{ route('password') }}" class="menu-link px-5">
                                        <span class="menu-text">Update Password</span>
                                        <span class="menu-badge">
                                            <!-- <span class="badge badge-light-danger badge-circle fw-bold fs-7">3</span> -->
                                        </span>
                                    </a>
                                </div>
                                <div class="menu-item px-5">
                                    <button type="button" class="menu-link px-5 userLogoutBtn">
                                        Sign Out
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="me-2 desktop-only">
                            <!--begin::Username-->
                            <a href="#"
                                class="app-sidebar-username text-gray-800 text-hover-primary fs-6 fw-semibold lh-0">{{ firstName ?? '--' }}
                                {{ lastName ?? '--' }}</a>
                            <!--end::Username-->

                            <!--begin::Description-->
                            <span class="app-sidebar-deckription text-gray-500 fw-semibold d-block fs-8">My
                                Account</span>
                            <!--end::Description-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Navbar-->
    </div>
    <!--end::Header wrapper-->
</div>
    <!-- </header> -->
</template>

<script>
export default {
    name: "Header",
};
</script>

<style scoped>
.header {
    background-color: #fff;
    border-bottom: 1px solid #ddd;
    padding: 10px 20px;
}
</style>

<script setup>
import LogoDark from "./LogoDark.vue";
</script>
<template>
  <div>
    <LogoDark />
  </div>
</template>

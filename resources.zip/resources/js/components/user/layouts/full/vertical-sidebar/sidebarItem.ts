import {
  LayoutDashboardIcon,BorderAllIcon,
  AlertCircleIcon,
  HomeDollarIcon,
  CreditCardIcon,
  WalletIcon, ChartLineIcon, MessageCircleIcon, UserPlusIcon
} from 'vue-tabler-icons';

export interface menu {
  header?: string;
  title?: string;
  icon?: any;
  to?: string;
  chip?: string;
  BgColor?: string;
  chipBgColor?: string;
  chipColor?: string;
  chipVariant?: string;
  chipIcon?: string;
  children?: menu[];
  disabled?: boolean;
  type?: string;
  subCaption?: string;
}

const sidebarItem: menu[] = [
  { header: 'Account' },
  {
    title: 'Dashboard',
    icon: LayoutDashboardIcon, // Dashboard-related icon
    BgColor: 'primary',
    to: '/'
  },
  {
    title: "Mortgage Details",
    icon: HomeDollarIcon, // Icon representing home and financial details
    BgColor: 'primary',
    to: "/account",
  },
  {
    title: "My Cards",
    icon: CreditCardIcon, // Credit card-related icon
    BgColor: 'primary',
    to: "/cards",
  },
  {
    title: "Wallet",
    icon: WalletIcon, // Wallet-related icon
    BgColor: 'primary',
    to: "/wallet",
  },
  {
    title: "Credit Advisory",
    icon: ChartLineIcon, // Icon representing financial or credit insights
    BgColor: 'primary',
    to: "/credit-advisory",
  },
  {
    title: "Help & support",
    icon: MessageCircleIcon, // Chat-related icon
    BgColor: 'primary',
    to: "/support",
  },
];

export default sidebarItem;

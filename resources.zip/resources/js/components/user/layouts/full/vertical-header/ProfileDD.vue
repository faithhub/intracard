<script>
import { UserIcon, SettingsIcon } from "vue-tabler-icons";
import { useAuthStore } from "@/stores/authStore";

export default {
  methods: {
    async logout() {
      const authStore = useAuthStore();
      await authStore.logout();
    },
  },
};
</script>

<template>
  <v-menu :close-on-content-click="false" offset-y>
    <!-- Avatar Button -->
    <template v-slot:activator="{ props }">
      <v-btn v-bind="props" variant="text" icon>
        <v-avatar size="45">
          <img src="@/assets/images/profile/user-1.jpg" alt="user" />
        </v-avatar>
      </v-btn>
    </template>

    <!-- Dropdown Menu -->
    <v-card elevation="10" class="rounded-xl py-4 px-4 user-dropdown-card">
      <!-- User Info Section -->
      <div class="d-flex align-center mb-4">
        <v-avatar size="60">
          <img src="@/assets/images/profile/user-1.jpg" alt="User Avatar" />
        </v-avatar>
        <div class="ml-3">
          <h4 class="text-h6 mb-1 font-weight-bold">Faith Amao</h4>
          <p class="text-caption text-muted">rent_new@gmail.com</p>
        </div>
      </div>

      <v-divider></v-divider>

      <!-- Menu Items -->
      <v-list class="mt-3" dense>
        <v-list-item to="/profile" value="profile" link>
          <template v-slot:prepend>
            <UserIcon class="text-primary" stroke-width="1.5" size="20" />
          </template>
          <v-list-item-title>My Profile</v-list-item-title>
          <v-list-item-subtitle>Account settings</v-list-item-subtitle>
        </v-list-item>

        <v-list-item to="/settings" value="settings" link>
          <template v-slot:prepend>
            <SettingsIcon class="text-info" stroke-width="1.5" size="20" />
          </template>
          <v-list-item-title>Settings</v-list-item-title>
          <v-list-item-subtitle>Application preferences</v-list-item-subtitle>
        </v-list-item>
      </v-list>

      <v-divider></v-divider>

      <!-- Logout Button -->
      <div class="text-center mt-4">
        <v-btn
          block
          class="logout-btn rounded-pill"
          @click="logout"
        >
          Logout
        </v-btn>
      </div>
    </v-card>
  </v-menu>
</template>

<style scoped>
.user-dropdown-card {
  max-width: 320px;
  border-radius: 16px;
  padding: 16px;
  background-color: #f8f9fa; /* Light gray for a clean look */
}

.text-muted {
  color: #6c757d !important;
}

.font-weight-bold {
  font-weight: 700 !important;
}

/* Logout Button Custom Style */
.logout-btn {
  background-color: #210035 !important; /* Custom dark purple */
  color: #fff !important; /* White text for contrast */
  font-weight: bold;
  padding: 10px 20px;
  transition: background-color 0.3s ease;
}

.logout-btn:hover {
  background-color: #37004d !important; /* Slightly lighter purple on hover */
}

/* Adjust Avatar Section */
.d-flex.align-center {
  align-items: center;
  gap: 16px;
}

/* Menu Item Titles */
.v-list-item-title {
  font-weight: 600 !important; /* Slightly bold */
  font-size: 14px;
}

.v-list-item-subtitle {
  font-size: 12px;
  color: #6c757d !important; /* Muted text for subtitles */
}

/* Divider Style */
.v-divider {
  margin: 8px 0;
  background-color: #e0e0e0;
}
</style>

<template>
    <div id="kt_app_header" class="app-header">
      <div class="app-container container-fluid d-flex align-items-stretch justify-content-between">
        <div class="d-flex align-items-center d-lg-none ms-n2 me-2">
          <button class="btn btn-icon" id="kt_app_sidebar_mobile_toggle">
            <i class="fa fa-bars"></i>
          </button>
        </div>
        <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
          <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
            <h1 class="page-heading text-gray-900 fw-bold fs-3">Dashboard</h1>
            <ul class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="/">Home</a>
              </li>
              <li class="breadcrumb-item">Rental Details</li>
            </ul>
          </div>
          <div class="app-navbar align-items-center">
            <div class="app-navbar-item ms-2">
              <i class="fa fa-bell fs-2"></i>
            </div>
            <div class="app-navbar-item">
              <img src="https://img.freepik.com/premium-vector/avatar-icon0002_750950-43.jpg" alt="User" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
<script>
export default {
    name: "Header",
};
</script>

<style scoped>
.header {
    background-color: #fff;
    border-bottom: 1px solid #ddd;
    padding: 10px 20px;
}
</style>

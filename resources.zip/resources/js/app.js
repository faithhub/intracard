// // import "./bootstrap";
// // import { createApp } from "vue";
// // import ChatComponent from "../components/ChatComponent.vue"; // Adjust the path based on your file structure

// // const app = createApp({});
// // app.component("chat-component", ChatComponent);
// // app.mount("#app");

// // window.Echo.channel("test-channel").listen("TestEvent", (event) => {
// //     console.log("Received Event:", event.message);
// // });
// import "./bootstrap";
// import { createApp } from "vue";
// import router from './router';
// import App from "../views/App.vue";

// createApp(App)
//     .use(router)
//     .mount("#app");


// // Import your Vue components
// import ChatComponent from "../components/ChatComponent.vue";
// // import BillingTabs from "../components/BillingTabs.vue";
// // import AddCardModal from "../components/AddCardModal.vue";

// // Create Vue application
// const app = createApp({});
// app.use(router);
// // Register components
// app.component("chat-component", ChatComponent); // For the chat section
// // app.component("billing-tabs", BillingTabs); // For the billing tabs
// // app.component("add-card-modal", AddCardModal); // For the add card modal

// // Mount Vue app
// app.mount("#app");

// // Laravel Echo setup (for real-time events)
// window.Echo.channel("test-channel").listen("TestEvent", (event) => {
//     console.log("Received Event:", event.message);
// });

// Import dependencies
// import "./bootstrap";
// import { createApp } from "vue";
// import router from "./router"; // Import Vue Router
// import App from "../views/App.vue"; // Root Vue Component

// // Create the Vue application
// const app = createApp(App);

// // Use Vue Router
// app.use(router);

// // Register additional components globally (if needed)
// import ChatComponent from "../components/ChatComponent.vue";
// app.component("chat-component", ChatComponent);

// // Laravel Echo setup for real-time events
// window.Echo.channel("test-channel").listen("TestEvent", (event) => {
//     console.log("Received Event:", event.message);
// });

// // Mount the Vue application to the #app element in app.blade.php
// app.mount("#app");
// import './variables';
import 'vuetify/styles/main.sass';
import "./bootstrap";
import { createPinia } from "pinia";
import { createApp } from "vue";
import router from "@/router"; // Vue Router
import App from "../views/App.vue"; // Root Vue component
import Toast, { POSITION } from "vue-toastification";
import "vue-toastification/dist/index.css";
import "@/scss/style.scss"; // Custom SCSS styles
import { createVuetify } from "vuetify";
import "vuetify/styles"; // Vuetify styles
import axios from "@/utils/axios"; // Axios setup
import { useAuthStore } from "@/stores/authStore"; // Adjust the path if necessary
import { startSessionTimers, resetSessionTimers, handleSessionTimeout } from "@/utils/sessionManager";

import jQuery from 'jquery';
window.$ = window.jQuery = jQuery

import 'jquery-confirm/css/jquery-confirm.css';
import 'jquery-confirm/js/jquery-confirm.js';


import jqueryConfirm from 'jquery-confirm'

$['confirm'] = jqueryConfirm

// Start session timers
startSessionTimers();

// Add listeners to reset session timers
document.addEventListener("mousemove", resetSessionTimers);
document.addEventListener("keydown", resetSessionTimers);

// Periodic session validation
setInterval(async () => {
    const authStore = useAuthStore();
    if (!authStore.isAuthenticated) {
        // Skip session ping if the user is not authenticated
        return;
    }

    try {
        const response = await axios.get("/api/ping");
        if (response.data.status === "success") {
            console.log("Session active");
        }
    } catch (error) {
        if (error.response && error.response.status === 401) {
            handleSessionTimeout();
        }
    }
}, 300000); // Ping every 5 minutes


// Vuetify setup
const vuetify = createVuetify();

// Vue Toast options
const toastOptions = {
    position: POSITION.TOP_RIGHT,
    timeout: 5000,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    draggablePercent: 0.6,
    hideProgressBar: false,
    closeButton: "button",
};

// Initialize Vue application
const app = createApp(App);
const pinia = createPinia();

app.use(vuetify);
app.use(router);
app.use(Toast, toastOptions);
app.use(pinia);

// Add global methods


// Mount the application
app.mount("#app");

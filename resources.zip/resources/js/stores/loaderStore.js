import { ref } from "vue";

const isLoading = ref(false);

export function useLoaderStore() {
  return {
    showLoader() {
      console.log("Loader shown");
      isLoading.value = true; // Update the reactive state
    },
    hideLoader() {
      console.log("Loader hidden");
      isLoading.value = false; // Reset the reactive state
    },
    get isLoading() {
      console.log("Accessing isLoading:", isLoading.value);
      return isLoading;
    },
  };
}

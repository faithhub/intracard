import axios from "axios";
import router from "@/router"; // Your Vue router
import { useAuthStore } from "@/stores/authStore"; // Adjust the path if necessary
import { useLoaderStore } from "@/stores/loaderStore"; // Ensure this store is set up
import { handleSessionTimeout } from "@/utils/sessionManager";

// Axios Defaults
axios.defaults.withCredentials = true; // Include cookies in requests
axios.defaults.baseURL = import.meta.env.MIX_APP_API_URL || "/"; // Base URL
axios.defaults.timeout = 10000; // 10-second timeout

// Fetch CSRF token once
const csrfToken = document
    .querySelector('meta[name="csrf-token"]')
    ?.getAttribute("content");

// Fetch fresh CSRF token
const fetchCsrfToken = async () => {
    const response = await axios.get("/csrf-token");
    const newToken = response.data.csrfToken;
    axios.defaults.headers.common["X-CSRF-TOKEN"] = newToken;
    console.log("CSRF token refreshed:", newToken);
    return newToken;
};

// Add a request interceptor
axios.interceptors.request.use(
    response => response,
    (config) => {
        const authStore = useAuthStore(); // Access auth store dynamically
        try {
            const loaderStore = useLoaderStore(); // Access loader store dynamically
            loaderStore.showLoader(); // Show loader before making a request
        } catch (error) {
            console.warn("Loader store not initialized properly.", error);
        }

        const token = authStore?.token; // Get the authentication token

        // Add CSRF token if available
        if (csrfToken) {
            config.headers["X-CSRF-TOKEN"] = csrfToken;
        }

        // Add Authorization header if token is available
        if (token) {
            config.headers["Authorization"] = `Bearer ${token}`;
        }

        return config;
    },
    async (error) => {
        if (error.response && error.response.status === 419) {
            console.warn("CSRF token mismatch detected. Fetching new token...");
            return axios.get("/csrf-token").then((response) => {
                const newCsrfToken = response.data.csrfToken;

                // Update Axios with the new token
                axios.defaults.headers.common["X-CSRF-TOKEN"] = newCsrfToken;

                // Retry the original failed request
                const originalRequest = error.config;
                originalRequest.headers["X-CSRF-TOKEN"] = newCsrfToken;

                return axios(originalRequest);
            });
        }
        try {
            const loaderStore = useLoaderStore();
            loaderStore.hideLoader(); // Hide loader on request error
        } catch (error) {
            console.warn("Loader store not initialized properly.", error);
        }
        return Promise.reject(error);
    }
);

// Add a response interceptor
axios.interceptors.response.use(
    (response) => {
        try {
            const loaderStore = useLoaderStore();
            loaderStore.hideLoader(); // Hide loader after successful response
        } catch (error) {
            console.warn("Loader store not initialized properly.", error);
        }
        return response;
    },
    async (error) => {
        try {
            const loaderStore = useLoaderStore();
            loaderStore.hideLoader(); // Hide loader after error response
        } catch (error) {
            console.warn("Loader store not initialized properly.", error);
        }

        if (error.response) {
            // Handle 401 Unauthorized errors
            if (error.response.status === 401) {
                const authStore = useAuthStore();
                authStore.stopSessionPing(); // Stop session ping
                authStore.clearAuth(); // Clear authentication state
                handleSessionTimeout(); // Trigger session timeout handling
            }
        }
        return Promise.reject(error);
    }
);

export default axios;

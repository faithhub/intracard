// import { useToast } from "/node_modules/.vite/deps/vue-toastification.js?v=e36c73ba";
// import router from "/resources/js/router/index.js?t=1734790611998"; // Adjust path to your router setup
// import axios from "/resources/js/utils/axios.js?t=1734790611998"; // Adjust path to your Axios setup
// import { useAuthStore } from "/resources/js/stores/authStore.js?t=1734790611998"; // Adjust the path if necessary

import { useToast } from 'vue-toastification'; // Use the package name directly
import router from '@/router/index.js';
import axios from '@/utils/axios.js';
import { useAuthStore } from '@/stores/authStore.js';

let sessionTimeoutHandled = false; // Flag to prevent multiple alerts
let sessionTimeoutWarning;
let sessionTimeout;

export function handleSessionTimeout() {
    const authStore = useAuthStore();
    if (sessionTimeoutHandled || !authStore.isAuthenticated) return;

    sessionTimeoutHandled = true;

    const toast = useToast();
    // Clear localStorage
    localStorage.removeItem("user");
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("authToken");

    // Clear Axios token
    delete axios.defaults.headers.common["Authorization"];

    // Display notification
    toast.warning("Session expired. Please log in again.", {
        timeout: 5000,
    });

    // Redirect to login page
    router.push({ name: "Login" }); // Use `router.push` instead of `next`

    sessionTimeoutHandled = false; // Reset flag after navigation
}

export function startSessionTimers() {
    sessionTimeoutWarning = setTimeout(() => {
        const toast = useToast();
        toast.info(
            "Your session will expire soon. Please refresh or continue using the app.",
            { timeout: 60000 } // 1-minute warning
        );
    }, 14 * 60 * 1000); // 14 minutes

    sessionTimeout = setTimeout(() => {
        handleSessionTimeout();
    }, 15 * 60 * 1000); // 15 minutes
}

export function resetSessionTimers() {
    clearTimeout(sessionTimeoutWarning);
    clearTimeout(sessionTimeout);
    startSessionTimers();
}

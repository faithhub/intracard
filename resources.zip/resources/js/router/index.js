import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from "@/stores/authStore"; // Import Pinia's Auth Store
import { handleSessionTimeout } from "@/utils/sessionManager";
import { useLoaderStore } from "@/stores/loaderStore";
import axios from "axios";
import userRoutes from "./userRoutes";

const routes = [
    ...userRoutes,
    {
        path: "",
        name: "HomeRoot",
        component: () => import("@/components/home/LandingPage.vue"),
    },
    {
        path: "/home",
        name: "Home",
        component: () => import("@/components/home/LandingPage.vue"),
    },
    {
        path: "/auth/sign-in",
        name: "Login",
        component: () => import("@/components/auth/Login.vue"),
        meta: { guest: true },
    },
    {
        path: "/:pathMatch(.*)*",
        name: "NotFound",
        component: () => import("@/components/errors/NotFound.vue"),
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

// Navigation Guard
router.beforeEach(async (to, from, next) => {
    const loaderStore = useLoaderStore();
    const authStore = useAuthStore();

    loaderStore.showLoader(); // Show loader during navigation

    try {
        // Skip authentication checks for unrestricted routes like Home
        if (!to.meta.requiresAuth && !to.meta.guest) {
            loaderStore.hideLoader();
            return next(); // Allow access to unrestricted routes
        }

        // Redirect authenticated users away from guest-only routes
        if (to.meta.guest && authStore.isAuthenticated) {
            console.log("Authenticated user trying to access a guest-only route. Redirecting to Dashboard.");
            loaderStore.hideLoader();
            return next({ name: "Dashboard" }); // Redirect to dashboard
        }

        // Check if user is authenticated for protected routes
        if (to.meta.requiresAuth && !authStore.isAuthenticated) {
            try {
                const response = await axios.get("/auth/status");
                if (response.data.authenticated) {
                    authStore.setAuth(response.data.user, null); // Set authenticated user
                } else {
                    console.log("User not authenticated, redirecting to login.");
                    loaderStore.hideLoader();
                    return next({ name: "Login" });
                }
            } catch (error) {
                console.error("Error during auth check. Redirecting to login:", error);
                loaderStore.hideLoader();
                return next({ name: "Login" });
            }
        }

        // Validate session for authenticated users
        if (authStore.isAuthenticated) {
            try {
                await axios.get("/api/ping");
            } catch (error) {
                if (error.response && error.response.status === 401) {
                    console.warn("Session expired or unauthorized. Redirecting to login.");
                    handleSessionTimeout(); // Clear authentication state
                    loaderStore.hideLoader();
                    return next({ name: "Login" });
                }
            }
        }

        // Load user settings if not already loaded
        if (authStore.isAuthenticated && (!authStore.settings || !Object.keys(authStore.settings).length)) {
            await authStore.fetchSettings();
        }

        // OTP verification logic
        const otpRequired = authStore.settings?.enable_2fa === "true";
        const otpVerified = authStore.user?.otp_verified;

        if (to.name === "OTPVerify") {
            if (!otpRequired) {
                loaderStore.hideLoader();
                return next({ name: "Dashboard" });
            }
            if (otpRequired && otpVerified) {
                loaderStore.hideLoader();
                return next({ name: "Dashboard" });
            }
        }

        if (to.meta.requiresOtp && otpRequired && !otpVerified) {
            loaderStore.hideLoader();
            return next({ name: "OTPVerify" });
        }

        // Default: Allow access to the route
        next();
    } catch (error) {
        console.error("Error during route navigation:", error);
        next(error); // Pass error to Vue Router's error handler
    } finally {
        loaderStore.hideLoader(); // Ensure loader is hidden after navigation
    }
});

// After Navigation Hook
router.afterEach(() => {
    const loaderStore = useLoaderStore();
    setTimeout(() => loaderStore.hideLoader(), 300); // Hide loader after 300ms
});

export default router;

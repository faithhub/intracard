<!DOCTYPE html>
<html>
<head>
    <title>Team Invitation</title>
</head>
<body>
    <h1>You have been invited to join a team!</h1>
    <p>Hello,</p>
    <p>You have been invited to join the team <strong>{{ $details['team_name'] }}</strong> by {{ $details['admin_name'] }} ({{ $details['admin_email'] }}).</p>
    <p>Please click the link below to accept the invitation:</p>
    <a href="{{ route('team.invitation.accept', ['team' => $details['team_name']]) }}">Accept Invitation</a>
    <p>If you didn’t expect this invitation, you can ignore this email.</p>
    <p>Thank you!</p>
</body>
</html>

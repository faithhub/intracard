<div class="error-page">
    <h1>{{ $message }}</h1>
    <a href="/dashboard" class="btn btn-primary">Go Back to Dashboard</a>
</div>

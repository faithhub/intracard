<template>
    <div>
        <!-- Loader -->
        <Loader v-if="showLoader" />

        <!-- Main app content -->
        <router-view />
    </div>
</template>

<script>
import { useLoaderStore } from "@/stores/loaderStore";
import { useAuthStore } from "@/stores/authStore";
import { loadAssets } from "@/utils/assetLoader";
import Loader from "@/components/Loader.vue";

export default {
    components: {
        Loader, // Dynamic import of the Loader component
    },

    setup() {
        const loaderStore = useLoaderStore();

        // Bind the reactive `isLoading` state to `showLoader`
        return {
            showLoader: loaderStore.isLoading,
        };

    },

    async mounted() {
        const authStore = useAuthStore();
        const loaderStore = useLoaderStore();

       loaderStore.showLoader();
        try {
            // Check authentication status
            if (authStore.isAuthenticated) {
                await authStore.fetchAuthStatus(); // Fetch authenticated user data
                const role = authStore.user?.role || "guest";
                loadAssets(role); // Load assets based on user role
                authStore.startSessionPing(); // Start session pings
            } else {
                loadAssets("guest"); // Load guest assets
                authStore.stopSessionPing(); // Stop session pings for logged-out users
            }
        } catch (error) {
            console.error("Error during app initialization:", error);
        } finally {
            // Hide the loader once initialization is complete
            loaderStore.hideLoader();
        }
    },
};
</script>

<style>
/* Add global styles if needed */
</style>

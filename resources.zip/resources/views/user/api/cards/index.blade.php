<div id="app">
    <cards-list :cards-data="{{ $cards->toJson() }}"></cards-list>
</div>